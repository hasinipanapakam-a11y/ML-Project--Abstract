"""🎬 CineMatch — Your watch history. Your next movie."""
from __future__ import annotations

import copy
import datetime as dt
import html
import random
from pathlib import Path

import numpy as np
import streamlit as st

import pandas as pd

from src.collaborative import HAS_SURPRISE, build_svd_model
from src.content_based import build_content_model
from src.personalization import (BADGES, MOODS, NIGHT_COMPANY, NIGHT_LEVEL, NIGHT_MOOD, dominant_genres,
                                 genre_section_title, milestones, profile_label, taste_evolution, taste_stats)
from src.compare import (build_rating_index, co_rating_stats, compare_lists, content_recs_for_movie, content_recs_for_user,
                         cf_recs_for_movie, cf_recs_for_user, evaluate_offline)
import src.auth as auth
import src.poster_utils as PU
from src.poster_utils import get_api_key, get_art, prefetch, safe_fetch, test_connection
from src.recommender import Engine
from src.theme import CSS
from src.utils import genre_label, load_data

st.set_page_config(page_title="CineMatch — Your watch history. Your next movie.", page_icon="🎬",
                   layout="wide", initial_sidebar_state="collapsed")

DATA_DIR = Path(__file__).parent / "data"
HISTORY_LIMIT = 20
PAGES = ["🏠 Home", "⚖️ Compare Both", "🎭 Discover", "🌎 Explore", "❤️ My Space", "🤖 How it works"]
P_HOME, P_CMP, P_DISC, P_EXPL, P_SPACE, P_HOW = PAGES
MODES = {"🎯 FAMILIAR": "familiar", "🌶️ EXPLORE": "explore", "🎲 WILD": "wild"}
ROW = 6  # cards per row (CSS wraps on narrow screens)
S = st.session_state


# ───────────────────────────────────────────────────────────── cached resources
@st.cache_data(show_spinner=False)
def _dataset():
    return load_data(DATA_DIR)


@st.cache_resource(show_spinner="🎬 Building content model…")
def _content():
    return build_content_model(_dataset()["movies"])


@st.cache_resource(show_spinner="🧠 Training SVD on MovieLens ratings…")
def _svd():
    d = _dataset()
    bundle = build_svd_model(d["ratings"], d["movies"]["movieId"].to_numpy())
    bundle["user_rated"] = d["ratings"].groupby("userId")["movieId"].apply(list).to_dict()
    bundle["heavy_users"] = d["ratings"]["userId"].value_counts().head(15).index.tolist()
    return bundle


@st.cache_resource(show_spinner=False)
def _rating_index():
    return build_rating_index(_dataset()["ratings"])


@st.cache_resource(show_spinner="📐 Running the offline evaluation…")
def _evaluation():
    return evaluate_offline(_engine(), _dataset()["ratings"], _svd(), max_users=6000)


@st.cache_resource(show_spinner=False)
def _engine():
    return Engine(_dataset()["movies"], _content(), _svd())


@st.cache_data(show_spinner=False)
def _report():
    return _dataset()["report"]


E = _engine()
KEY = get_api_key(S.get("tmdb_key"))


ART_OPTS = ["Strict · G to PG-13 only", "Standard · hide R & 18+", "Off"]
ART_LEVELS = {ART_OPTS[0]: "strict", ART_OPTS[1]: "standard", ART_OPTS[2]: "off"}


def _art(info: dict) -> dict:
    """Artwork for one movie honouring the family-friendly setting."""
    return get_art(info, KEY, ART_LEVELS.get(S.get("art_level", ART_OPTS[0]), "strict"))


# ─────────────────────────────────────────────────────────────── session state
DEFAULTS = dict(
    page=P_HOME, watch_history=[], watchlist=[], selected_mood=None, faceoff_preferences=[],
    faceoff_pair=None, faceoff_pick=None, recent_recommendations=[], surprise_history=[], surprise_current=None,
    onboarding_genres=[], moods_tried=[], watched_ever=0, saved_ever=0, genres_seen=[], discovery="🎯 FAMILIAR",
    detail_id=None, more_like_id=None, search_q="", todays_pick=None, genre_sel=None, genre_n=18, search_n=24,
    double_seed=0, bed_seed=0, night_seed=0, night_on=False, faceoff_seed=0, world_group="🇺🇸 Hollywood",
    cmp_mode="🎬 By movie", cmp_n=8, cmp_movie=None, cmp_user=None, cmp_eval=False,
    user=None, guest=False, auth_msg=None, last_saved="", art_level="Strict · G to PG-13 only",
)
for _k, _v in DEFAULTS.items():
    if _k not in S:
        S[_k] = copy.deepcopy(_v)
if "seed" not in S:
    S["seed"] = random.randint(1, 10_000)
if S.genre_sel is None and E.genres:
    S.genre_sel = E.genres[0]
MOVIE_OPTS = E.m.sort_values("n_ratings", ascending=False)["movieId"].astype(int).tolist()
if S.cmp_movie not in MOVIE_OPTS:
    _ts = E.m.loc[E.m["name"] == "Toy Story", "movieId"]
    S.cmp_movie = int(_ts.iloc[0]) if len(_ts) else MOVIE_OPTS[0]


def ctx() -> dict:
    return dict(history=S.watch_history, list=S.watchlist, faceoff=S.faceoff_preferences,
                onboarding=S.onboarding_genres)


def toast(msg: str):
    try:
        st.toast(msg)
    except Exception:
        pass


# ────────────────────────────────────────────────────────────────── callbacks
def act_watch(mid: int):
    h = S.watch_history
    if mid in h:  # already watched -> toggle off
        h.remove(mid)
        S.watch_history = h
        toast("Removed from Watch History")
        return
    h.insert(0, mid)
    S.watch_history = h[:HISTORY_LIMIT]
    S.watched_ever += 1
    info = E.info_by_id(mid)
    for g in (info or {}).get("genres", []):
        if g not in S.genres_seen:
            S.genres_seen.append(g)
    toast("🎬 Added to Watch History")


def act_list(mid: int):
    if mid in S.watchlist:
        S.watchlist.remove(mid)
        toast("Removed from My List")
    else:
        S.watchlist.insert(0, mid)
        S.saved_ever += 1
        toast("❤️ Added to My List")


def act_compare(mid: int):
    S.cmp_movie, S.cmp_mode, S.page = int(mid), "🎬 By movie", P_CMP


def act_detail(mid: int):
    S.detail_id = mid
    S.more_like_id = None


def act_close_detail():
    S.detail_id = None
    S.more_like_id = None


def act_more_like(mid: int):
    S.more_like_id = mid


def act_mood(k: str):
    S.selected_mood = None if S.selected_mood == k else k
    if S.selected_mood:
        if k not in S.moods_tried:
            S.moods_tried.append(k)
        toast("🎭 Mood selected")


def act_surprise():
    seen = list(S.surprise_history) + list(S.recent_recommendations[-12:])
    rec = E.surprise(ctx(), seen, S.seed + 7919 * (len(S.surprise_history) + 1))
    if rec is None:  # pool exhausted: start over rather than repeat silently
        S.surprise_history = []
        rec = E.surprise(ctx(), [], S.seed + 31)
    if rec:
        S.surprise_history.append(rec["movieId"])
        S.surprise_current = rec
    S.page = P_DISC
    toast("🎲 CineMatch found something for you...")


def act_faceoff_pick(mid: int):
    p = [m for m in S.faceoff_preferences if m != mid]
    S.faceoff_preferences = ([mid] + p)[:10]
    S.faceoff_pick = mid
    toast("👀 Nice pick!")


def act_new_faceoff():
    S.faceoff_seed += 1
    S.faceoff_pair = None
    S.faceoff_pick = None


def act_goto(page: str, genre: str | None = None):
    S.page = page
    if genre:
        S.genre_sel, S.genre_n = genre, 18


def act_genre(g: str):
    S.genre_sel, S.genre_n = g, 18


def act_clear_search():
    S.search_q = ""


def act_save_onboarding():
    toast("🍿 Taste saved")


def act_reset():
    for k, v in DEFAULTS.items():
        if k not in ("user", "guest", "auth_msg", "last_saved"):
            S[k] = copy.deepcopy(v)
    S.genre_sel = E.genres[0] if E.genres else None


def act_inc(key: str, by: int = 1):
    S[key] = S[key] + by


# ───────────────────────────────────────────────────────────────── components
def esc(x) -> str:
    return html.escape(str(x), quote=True)


def section(title: str, sub: str | None = None):
    st.markdown(f'<div class="cm-sec"><h3>{esc(title)}</h3>{f"<span>{esc(sub)}</span>" if sub else ""}</div>',
                unsafe_allow_html=True)


def _bg(card_url: str | None, fb: str, overlay: str = "") -> str:
    layers = ([overlay] if overlay else []) + ([f"url('{card_url}')"] if card_url else []) + [f"url('{fb}')"]
    return ",".join(layers)


def card_html(info: dict, art: dict, badge: str = "", why: str = "") -> str:
    rate = f'<span class="cm-rate" title="{info["n"]} ratings">⭐ {info["avg"]:.1f}</span>' if info["avg"] else ""
    if art.get("blocked"):
        badge = "🛡️ Age-rated · artwork hidden"
    b = f'<span class="cm-badge">{esc(badge)}</span>' if badge else ""
    yr = f' · {info["year"]}' if info["year"] else ""
    genres = " · ".join(info["genres"][:3]) or "—"
    w = (f'<details class="cm-why"><summary>💡 Why this pick?</summary><p>{esc(why)}</p></details>' if why else "")
    return (f'<div class="cm-card"><div class="cm-art" style="background-image:{_bg(art["card"], art["fallback"])}">{b}{rate}</div>'
            f'<div class="cm-meta2"><div class="cm-title" title="{esc(info["name"])}">{esc(info["name"])}</div>'
            f'<div class="cm-sub">{esc(genres)}{yr}</div>{w}</div></div>')


def _info_art(mid: int):
    info = E.info_by_id(mid)
    return info, (_art(info) if info else None)


def render_card(rec: dict, key: str, pick_cb=None):
    """One OTT card + compact action buttons (✓ watched · ♥/＋ list · ⓘ details)."""
    mid = rec["movieId"]
    info, art = _info_art(mid)
    if not info:
        return
    st.markdown(card_html(info, art, rec.get("badge", ""), rec.get("why", "")), unsafe_allow_html=True)
    b1, b2, b3 = st.columns(3)
    w, l = mid in S.watch_history, mid in S.watchlist
    b1.button("✓", key=f"w_{key}", on_click=act_watch, args=(mid,), type="primary" if w else "secondary",
              use_container_width=True, help="In your Watch History — click to remove" if w else "Mark as watched")
    b2.button("♥" if l else "＋", key=f"l_{key}", on_click=act_list, args=(mid,), type="primary" if l else "secondary",
              use_container_width=True, help="Remove from My List" if l else "Add to My List")
    b3.button("ⓘ", key=f"d_{key}", on_click=act_detail, args=(mid,), use_container_width=True, help="Details")
    if pick_cb:
        st.button("❤️ I'D WATCH THIS", key=f"p_{key}", on_click=pick_cb, args=(mid,), type="primary",
                  use_container_width=True)


def track(recs: list[dict]):
    r = S.recent_recommendations
    for x in recs:
        if x["movieId"] in r:
            r.remove(x["movieId"])
        r.append(x["movieId"])
    S.recent_recommendations = r[-80:]


def movie_row(title: str, recs: list[dict], key: str, sub: str | None = None, rows: int = 1):
    recs = [r for r in recs if E.info_by_id(r["movieId"])][: ROW * rows]
    if not recs:
        return
    section(title, sub)
    infos = [E.info_by_id(r["movieId"]) for r in recs]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos], KEY)
    for r0 in range(0, len(recs), ROW):
        cols = st.columns(ROW)
        for pos, (c, rec) in enumerate(zip(cols, recs[r0:r0 + ROW])):
            with c:
                render_card(rec, f"{key}_{r0 + pos}_{rec['movieId']}")
    track(recs)


def hero(rec: dict | None):
    if not rec:
        return
    info, art = _info_art(rec["movieId"])
    prefetch([(info["tmdbId"], info["name"], info["year"])], KEY)
    art = _art(info)
    meta = art["meta"]
    img = art["backdrop"] or art["card"]
    over = "linear-gradient(90deg,rgba(13,16,32,.97) 8%,rgba(13,16,32,.62) 55%,rgba(13,16,32,.12))"
    bg = _bg(img, art["fallback_wide"], over)
    ov = (meta.get("overview") or "")[:230]
    ov = ov + ("…" if len(meta.get("overview") or "") > 230 else "")
    rate = f'<span>⭐ {info["avg"]:.1f} <small>({info["n"]} ratings)</small></span>' if info["avg"] else ""
    poster_div = (f'<div class="cm-hero-poster" style="background-image:{_bg(art["poster"], art["fallback"])}"></div>'
                  if art["poster"] else "")
    st.markdown(
        f'<div class="cm-hero" style="background-image:{bg}"><div class="cm-hero-body"><div class="cm-eyebrow">🎯 TODAY\'S PICK</div>'
        f'<h1>{esc(info["name"])}</h1><div class="cm-meta"><span>{info["year"] or ""}</span><span>{esc(" · ".join(info["genres"][:4]))}</span>{rate}</div>'
        f'{f"<p class=cm-ov>{esc(ov)}</p>" if ov else ""}<div class="cm-whypill">💡 {esc(rec.get("why", ""))}</div></div>{poster_div}</div>',
        unsafe_allow_html=True)
    mid = info["movieId"]
    c1, c2, c3, _ = st.columns([1, 1, 1, 4])
    w, l = mid in S.watch_history, mid in S.watchlist
    c1.button("✓ Watched" if w else "▶ Watched", key="hero_w", on_click=act_watch, args=(mid,), type="primary",
              use_container_width=True)
    c2.button("♥ In My List" if l else "＋ My List", key="hero_l", on_click=act_list, args=(mid,), use_container_width=True)
    c3.button("ⓘ Details", key="hero_d", on_click=act_detail, args=(mid,), use_container_width=True)


def history_strip():
    if not S.watch_history:
        return
    section("🕒 WATCH HISTORY", "Most recent first — manage it in ❤️ My Space")
    infos = [E.info_by_id(m) for m in S.watch_history]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos if i], KEY)
    items = ""
    for i in infos:
        if not i:
            continue
        a = _art(i)
        items += (f'<div class="cm-mini"><div class="cm-art" style="background-image:{_bg(a["card"], a["fallback"])}"></div>'
                  f'<div class="t" title="{esc(i["name"])}">{esc(i["name"])}</div></div>')
    st.markdown(f'<div class="cm-strip">{items}</div>', unsafe_allow_html=True)


def todays_pick() -> dict | None:
    day = dt.date.today().isoformat()
    key = f"{day}|{bool(S.watch_history)}"
    tp = S.todays_pick
    if not tp or tp["key"] != key:
        rec = None
        for k in range(8):  # deterministic per day; skip adult-certified titles in family mode
            rec = E.todays_pick(ctx(), day if k == 0 else f"{day}#{k}")
            info = E.info_by_id(rec["movieId"]) if rec else None
            if not rec or not KEY or S.get("art_level") == ART_OPTS[2] or not _art(info)["blocked"]:
                break
        tp = {"key": key, "rec": rec}
        S.todays_pick = tp
    return tp["rec"]


def hstats() -> dict:
    infos = [E.info_by_id(m) for m in S.watch_history]
    infos = [i for i in infos if i]
    gcount = {g: int(c) for g, c in zip(E.genres, E.G.sum(0))}
    return taste_stats([i["genres"] for i in infos], [i["avg"] for i in infos],
                       [i["year"] if i["year"] else float("nan") for i in infos], gcount)


def mode() -> str:
    return MODES[S.discovery]


# ───────────────────────────────────────────────────────────────── sections
def empty_home():
    st.markdown('<div class="cm-banner"><h2>🍿 Your movie journey starts here.</h2>'
                '<p>Watch a movie and CineMatch will start building your personalized recommendations.</p></div>',
                unsafe_allow_html=True)
    with st.expander("✨ What kind of movies do you enjoy? (optional — pick 3–5 genres)", expanded=not S.onboarding_genres):
        st.multiselect("Genres", E.genres, key="onboarding_genres", max_selections=5, label_visibility="collapsed",
                       on_change=act_save_onboarding)
        st.caption("Used only as a starting signal until your Watch History takes over.")


def mood_section():
    section("🎭 WHAT'S YOUR MOOD?", "Pick a viewing mood — it's mapped to genres and blended with your watch history.")
    keys = list(MOODS)
    for row in (keys[:5], keys[5:]):
        for c, k in zip(st.columns(5), row):
            m = MOODS[k]
            c.button(f"{m['emoji']} {m['label']}", key=f"mood_{k}", on_click=act_mood, args=(k,),
                     type="primary" if S.selected_mood == k else "secondary", use_container_width=True)
    if S.selected_mood:
        m = MOODS[S.selected_mood]
        recs = E.mood_picks(ctx(), S.selected_mood, 6, mode(), rng_seed=S.seed + keys.index(S.selected_mood))
        movie_row(f"{m['emoji']} YOUR {m['title']} PICKS", recs, f"mood_{S.selected_mood}",
                  f"Mood-based picks ({S.discovery.split(' ', 1)[1].title()} discovery) · genres: "
                  + ", ".join(m["genres"]))


def discovery_selector():
    section("🧭 DISCOVERY MODE", "A diversity control: how close to — or far from — your watch history should picks be?")
    st.radio("Discovery", list(MODES), key="discovery", horizontal=True, label_visibility="collapsed")
    st.caption({"familiar": "Strongly similar to your watch history.",
                "explore": "Similar tastes, with deliberate variation (diversity re-ranking).",
                "wild": "Well-rated movies outside your usual genre profile."}[mode()])


def personalised_rows():
    c = ctx()
    h = S.watch_history
    if not h:
        return
    anchor = h[0]
    a = E.info_by_id(anchor)
    movie_row(f"🎬 BECAUSE YOU WATCHED {a['name'].upper()}", E.because_you_watched(c, anchor, ROW), "byw",
              "Content-Based Recommendations · TF-IDF + cosine similarity (genres, era, title keywords)")
    discovery_selector()
    movie_row("🎯 MADE FOR YOUR WATCH HISTORY", E.made_for_history(c, ROW * 2, mode(), S.seed), "mfh",
              f"Combines all {len(h)} watched movie{'s' if len(h) != 1 else ''} into one taste profile", rows=2)
    title, g = genre_section_title(hstats())
    if g:
        recs = E.genre_row(c, g, ROW)
    else:
        recs = E.multi_genre_row(c, dominant_genres(hstats(), 3, 0.2) or [x for x, _ in hstats()["counts"][:2]], ROW)
    movie_row(title, recs, "genre_pers", "Calculated from the genres in your Watch History")
    mix = E.mix_it_up(c, S.seed)
    if len(mix) == 3:
        movie_row("🧩 MIX IT UP", mix, "mix", "🎯 one familiar · 🌶️ one slightly different · 🎲 one wildcard")


def surprise_block():
    section("🎲 SURPRISE ME", "One unseen, well-rated movie that fits your taste — never repeated this session.")
    rec = S.surprise_current
    if not rec:
        st.button("🎲 SURPRISE ME", key="surprise_go", on_click=act_surprise, type="primary")
        return
    info, art = _info_art(rec["movieId"])
    prefetch([(info["tmdbId"], info["name"], info["year"])], KEY)
    art = _art(info)
    c1, c2 = st.columns([1, 2])
    with c1:
        st.markdown(card_html(info, art, "🎲 Surprise"), unsafe_allow_html=True)
    with c2:
        rate = f"⭐ {info['avg']:.1f}" if info["avg"] else ""
        st.markdown(f'<div class="cm-pick"><div class="cm-eyebrow">🎲 CINE MATCH PICK</div><h2>{esc(info["name"])}</h2>'
                    f'<div class="cm-meta"><span>{rate}</span><span>{info["year"] or ""}</span><span>{esc(" · ".join(info["genres"][:4]))}</span></div>'
                    f'<p class="cm-ov" style="margin-top:.6rem">“{esc(rec["why"])}”</p></div>', unsafe_allow_html=True)
        b1, b2, b3 = st.columns(3)
        b1.button("▶ Watch", key="sp_w", on_click=act_watch, args=(info["movieId"],), type="primary", use_container_width=True)
        b2.button("＋ My List", key="sp_l", on_click=act_list, args=(info["movieId"],), use_container_width=True)
        b3.button("🔄 Try Another", key="sp_n", on_click=act_surprise, use_container_width=True)


def faceoff_block():
    section("⚔️ PICK ONE", "Two movies, one choice. Your pick is a session-level preference signal — no model is retrained.")
    if not S.faceoff_pair:
        S.faceoff_pair = E.faceoff(ctx(), S.seed + 101 * S.faceoff_seed)
    pair = S.faceoff_pair
    if not pair:
        st.info("Not enough data for a face-off yet.")
        return
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in (E.info_by_id(m) for m in pair)], KEY)
    cA, cV, cB = st.columns([5, 1, 5])
    picking = S.faceoff_pick is None
    for col, mid, tag in ((cA, pair[0], "A"), (cB, pair[1], "B")):
        with col:
            st.markdown(f'<div class="cm-step">🎬 MOVIE {tag}</div>', unsafe_allow_html=True)
            render_card({"movieId": mid, "badge": "", "why": ""}, f"fo_{tag}_{mid}", pick_cb=act_faceoff_pick if picking else None)
    cV.markdown('<div class="cm-vs">VS</div>', unsafe_allow_html=True)
    if S.faceoff_pick is not None:
        p = E.info_by_id(S.faceoff_pick)
        st.success(f"Nice pick 👀  You'd watch **{p['name']}**.")
        movie_row("MORE LIKE YOUR PICK", E.more_like(ctx(), S.faceoff_pick, ROW), f"fo_more_{S.faceoff_pick}")
        st.button("⚔️ New face-off", key="fo_new", on_click=act_new_faceoff)


def night_block():
    section("🍿 MOVIE NIGHT", "Tell us the setup — we'll generate a short list.")
    c1, c2, c3 = st.columns(3)
    comp = c1.radio("Who are you watching with?", list(NIGHT_COMPANY), key="night_company",
                    format_func=lambda k: NIGHT_COMPANY[k]["label"])
    mood = c2.radio("Mood?", list(NIGHT_MOOD), key="night_mood")
    lvl = c3.radio("Discovery level?", list(NIGHT_LEVEL), key="night_level")
    st.button("🍿 Generate movie night", key="night_go", type="primary", on_click=lambda: (act_inc("night_seed"), S.update(night_on=True)))
    if S.night_on:
        recs = E.movie_night(ctx(), comp, mood, lvl, 4, S.seed + 13 * S.night_seed)
        if recs:
            movie_row(f"🍿 TONIGHT: {NIGHT_COMPANY[comp]['label']} · {mood} · {lvl}", recs, f"night_{S.night_seed}")
        else:
            st.info("No matches for that combination — try a different mood or discovery level.")


def double_block():
    section("🎬 DOUBLE FEATURE", "Two movies that pair well — based on shared genres and content similarity only.")
    df = E.double_feature(ctx(), S.seed + 17 * S.double_seed)
    if not df:
        st.info("No double feature available right now.")
        return
    infos = [E.info_by_id(df[k]["movieId"]) for k in ("first", "second")]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos], KEY)
    c1, cm, c2 = st.columns([5, 1, 5])
    with c1:
        st.markdown('<div class="cm-step">FIRST WATCH</div>', unsafe_allow_html=True)
        render_card({**df["first"], "badge": "① First"}, f"df_a_{df['first']['movieId']}")
    cm.markdown('<div class="cm-vs">➜</div>', unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="cm-step">SECOND WATCH</div>', unsafe_allow_html=True)
        render_card({**df["second"], "badge": "② Second"}, f"df_b_{df['second']['movieId']}")
    st.button("🔄 New double feature", key="df_new", on_click=act_inc, args=("double_seed",))
    track([df["first"], df["second"]])


def bedtime_block():
    section("🌙 ONE MOVIE BEFORE BED", "Exactly one unseen pick, tuned to your history and rating quality.")
    recs = E.bedtime(ctx(), S.seed + 5 * S.bed_seed)
    if not recs:
        return
    rec = recs[0]
    info = E.info_by_id(rec["movieId"])
    prefetch([(info["tmdbId"], info["name"], info["year"])], KEY)
    c1, c2 = st.columns([1, 3])
    with c1:
        render_card(rec, f"bed_{rec['movieId']}")
    with c2:
        st.markdown(f'<div class="cm-pick"><div class="cm-eyebrow">🌙 TONIGHT</div><h2>{esc(info["name"])}</h2>'
                    f'<p class="cm-ov">{esc(rec["why"])}</p></div>', unsafe_allow_html=True)
        st.button("🔄 Another one", key="bed_new", on_click=act_inc, args=("bed_seed",))
    track(recs)


def taste_block():
    st.markdown('<div class="cm-sec"><h3>📊 YOUR TASTE</h3><span>Calculated from your Watch History</span></div>', unsafe_allow_html=True)
    s = hstats()
    if not s["n"]:
        st.caption("Watch a movie to see your taste statistics.")
        return
    top = s["counts"][0][1]
    bars = "".join(f'<div class="cm-bar"><div class="n">{esc(genre_label(g))}</div><div class="tr"><div class="fl" style="width:{c / top * 100:.0f}%"></div></div><div class="v">{c}</div></div>'
                   for g, c in s["counts"][:8])
    cA, cB = st.columns([3, 2])
    cA.markdown(bars, unsafe_allow_html=True)
    avg = f"{s['avg_community_rating']:.2f}" if s["avg_community_rating"] else "—"
    cB.markdown(
        f'<div class="cm-stat"><b>{s["n"]}</b><span>Movies in history</span></div><div style="height:.5rem"></div>'
        f'<div class="cm-stat"><b>{esc(genre_label(s["favorite"]))}</b><span>Favorite genre</span></div><div style="height:.5rem"></div>'
        f'<div class="cm-stat"><b>{s["n_genres"]}</b><span>Genres explored</span></div><div style="height:.5rem"></div>'
        f'<div class="cm-stat"><b>{avg} ⭐</b><span>Avg. community rating of what you watched (you haven\'t rated in-app)</span></div>',
        unsafe_allow_html=True)


def profile_block():
    section("🧠 YOUR MOVIE PROFILE", "A label derived from your genre distribution — not a personality test")
    label, why = profile_label(hstats())
    st.markdown(f'<div class="cm-pick"><h2>{esc(label)}</h2><p class="cm-ov">{esc(why)}</p></div>', unsafe_allow_html=True)


def evolution_block():
    chrono = [E.info_by_id(m)["genres"] for m in reversed(S.watch_history) if E.info_by_id(m)]
    ev = taste_evolution(chrono)
    if not ev:
        return
    section("📈 YOUR TASTE EVOLUTION", "Earlier vs. recent half of your watch history")
    c1, c2 = st.columns(2)
    c1.markdown(f'<div class="cm-stat"><span>Earlier</span><b style="font-size:1.1rem">{esc(", ".join(ev["early"]))}</b></div>', unsafe_allow_html=True)
    c2.markdown(f'<div class="cm-stat"><span>Recently</span><b style="font-size:1.1rem">{esc(", ".join(ev["recent"]))}</b></div>', unsafe_allow_html=True)
    st.write(ev["message"])


def milestones_block():
    section("🏆 CINE-MILESTONES")
    ms = milestones(S.watched_ever, len(S.genres_seen), len(S.moods_tried), S.saved_ever)
    st.markdown("".join(f'<span class="cm-ms {"on" if m["unlocked"] else "off"}">{m["icon"]} {esc(m["name"])}</span>' for m in ms),
                unsafe_allow_html=True)


def list_block():
    section("❤️ MY LIST", "Saved for later")
    if not S.watchlist:
        st.caption("Your list is empty — tap ＋ on any movie to save it.")
        return
    recs = [{"movieId": m, "badge": BADGES["list"], "why": "Saved by you."} for m in S.watchlist]
    for r0 in range(0, len(recs), ROW):
        for pos, (c, rec) in enumerate(zip(st.columns(ROW), recs[r0:r0 + ROW])):
            with c:
                render_card(rec, f"mylist_{r0 + pos}_{rec['movieId']}")
    recs2, top = E.list_recs(ctx(), ROW)
    if recs2:
        movie_row("BECAUSE OF YOUR LIST", recs2, "blist", "Dominant genres in your list: " + ", ".join(top))


def history_block():
    section("🕒 WATCH HISTORY", f"Up to {HISTORY_LIMIT} most recent · click ✓ to remove")
    if not S.watch_history:
        st.caption("Nothing watched yet.")
        return
    recs = [{"movieId": m, "badge": "", "why": ""} for m in S.watch_history]
    infos = [E.info_by_id(m) for m in S.watch_history]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos], KEY)
    for r0 in range(0, len(recs), ROW):
        for pos, (c, rec) in enumerate(zip(st.columns(ROW), recs[r0:r0 + ROW])):
            with c:
                render_card(rec, f"hist_{r0 + pos}_{rec['movieId']}")


def detail_panel():
    mid = S.detail_id
    info = E.info_by_id(mid) if mid else None
    if not info:
        return
    prefetch([(info["tmdbId"], info["name"], info["year"])], KEY)
    art = _art(info)
    meta = art["meta"]
    over = "linear-gradient(90deg,rgba(11,14,28,.9),rgba(11,14,28,.5))"
    chips = "".join(f'<span class="cm-chip">{esc(genre_label(g))}</span>' for g in info["genres"])
    bits = []
    if info["avg"]:
        bits.append(f'⭐ {info["avg"]:.1f} community avg ({info["n"]} ratings)')
    if meta.get("vote_average"):
        bits.append(f'TMDB {meta["vote_average"]:.1f}')
    if meta.get("runtime"):
        bits.append(f'{meta["runtime"]} min')
    if meta.get("language"):
        bits.append(f'Original language: {meta["language"].upper()}')
    ov = meta.get("overview") or ("No overview available." if KEY else "Add a TMDB API key to see overviews, posters and backdrops.")
    tag = f'<i style="color:#b9b0ff">{esc(meta["tagline"])}</i>' if meta.get("tagline") else ""
    st.markdown(
        f'<div class="cm-detail" style="background-image:{_bg(art["backdrop"] or art["card"], art["fallback_wide"])}"><div class="cm-detail-in">'
        f'<div class="cm-detail-poster" style="background-image:{_bg(art["card"], art["fallback"])}"></div>'
        f'<div class="cm-detail-txt"><div class="cm-eyebrow">MOVIE DETAILS</div><h2>{esc(info["name"])} <small style="color:#9aa0c3;font-size:1rem">{info["year"] or ""}</small></h2>'
        f'<div>{chips}</div><div class="cm-meta">{" · ".join(esc(b) for b in bits)}</div>{tag}<p class="cm-ov">{esc(ov)}</p></div></div></div>',
        unsafe_allow_html=True)
    c1, c2, c3, c4, c5, _ = st.columns([1, 1, 1, 1, 1, 2])
    w, l = mid in S.watch_history, mid in S.watchlist
    c1.button("✓ Watched" if w else "▶ Watched", key="dt_w", on_click=act_watch, args=(mid,), type="primary", use_container_width=True)
    c2.button("♥ In List" if l else "＋ My List", key="dt_l", on_click=act_list, args=(mid,), use_container_width=True)
    c3.button("🔥 More Like This", key="dt_m", on_click=act_more_like, args=(mid,), use_container_width=True)
    c4.button("⚖️ Compare", key="dt_cmp", on_click=act_compare, args=(mid,), use_container_width=True, help="Content-based vs collaborative for this movie")
    c5.button("✕ Close", key="dt_c", on_click=act_close_detail, use_container_width=True)
    if S.more_like_id == mid:
        movie_row(f"🔥 MORE LIKE {info['name'].upper()}", E.more_like(ctx(), mid, ROW), f"ml_{mid}")


def search_results():
    q = S.search_q.strip()
    section(f"🔎 RESULTS FOR “{q}”")
    st.button("✕ Clear search", key="clr_search", on_click=act_clear_search)
    recs = E.search(q, S.search_n)
    if not recs:
        st.info("No movies matched. Try a shorter title, or a genre like “comedy”, “animation” or “scary”.")
        return
    infos = [E.info_by_id(r["movieId"]) for r in recs]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos], KEY)
    for r0 in range(0, len(recs), ROW):
        for pos, (c, rec) in enumerate(zip(st.columns(ROW), recs[r0:r0 + ROW])):
            with c:
                render_card(rec, f"srch_{r0 + pos}_{rec['movieId']}")
    if len(recs) >= S.search_n:
        st.button("Show more", key="srch_more", on_click=act_inc, args=("search_n", 12))


def genre_explorer():
    section("🌎 EXPLORE BY GENRE", "Only genres that exist in the dataset")
    gs = E.genres
    for r0 in range(0, len(gs), 6):
        for c, g in zip(st.columns(6), gs[r0:r0 + 6]):
            c.button(genre_label(g), key=f"gsel_{g}", on_click=act_genre, args=(g,),
                     type="primary" if S.genre_sel == g else "secondary", use_container_width=True)
    g = S.genre_sel
    recs = E.genre_top(g, ctx(), S.genre_n)
    movie_row(f"{genre_label(g).upper()}", recs, f"genre_{g}_{S.genre_n}", "Top-rated first (rating quality × popularity)", rows=(S.genre_n + ROW - 1) // ROW)
    st.button("Show more", key="genre_more", on_click=act_inc, args=("genre_n", 12))


def world_block():
    section("🌍 EXPLORE THE WORLD", "Based only on TMDB metadata (the CSVs contain no language/country)")
    if not KEY:
        st.caption("Add a TMDB API key to enable this section — language and country come from TMDB only.")
        return
    top = E.m.sort_values("n_ratings", ascending=False).head(120)
    items = [(None if np.isnan(r.tmdbId) else int(r.tmdbId), r["name"], None if np.isnan(r.year) else int(r.year)) for _, r in top.iterrows()]
    with st.spinner("Loading TMDB metadata…"):
        prefetch(items, KEY)
    groups: dict[str, list[int]] = {"🇺🇸 Hollywood": [], "🇮🇳 Indian": [], "🇯🇵 Japanese": [], "🇰🇷 Korean": [], "🌍 International": []}
    indian = {"hi", "ta", "te", "ml", "kn", "bn", "mr", "pa"}
    for (tid, name, yr), mid in zip(items, top["movieId"]):
        m = safe_fetch(tid, name, yr, KEY)
        lang = m.get("language")
        if not lang:
            continue
        if lang in indian or "IN" in m.get("countries", []):
            groups["🇮🇳 Indian"].append(int(mid))
        elif lang == "ja":
            groups["🇯🇵 Japanese"].append(int(mid))
        elif lang == "ko":
            groups["🇰🇷 Korean"].append(int(mid))
        elif lang == "en":
            groups["🇺🇸 Hollywood"].append(int(mid))
        else:
            groups["🌍 International"].append(int(mid))
    avail = [g for g, v in groups.items() if v]
    if not avail:
        st.caption("TMDB metadata is unavailable right now.")
        return
    if S.world_group not in avail:
        S.world_group = avail[0]
    st.radio("Region", avail, key="world_group", horizontal=True, label_visibility="collapsed")
    recs = [{"movieId": m, "badge": "🌍 World", "why": f"TMDB lists the original language/country as {S.world_group}."}
            for m in groups[S.world_group][:ROW * 2]]
    movie_row(S.world_group.upper(), recs, f"world_{S.world_group}", f"From the {len(items)} most-rated movies in the dataset", rows=2)


def how_it_works():
    r, svd = _report(), _svd()
    st.markdown('<div class="cm-sec"><h3>🤖 HOW CINEMATCH WORKS</h3><span>Technically accurate, no hand-waving</span></div>', unsafe_allow_html=True)
    cols = st.columns(5)
    for c, (v, lab) in zip(cols, [(f"{r['n_movies']:,}", "Movies"), (f"{r['n_ratings']:,}", "Ratings"), (f"{r['n_users']:,}", "Users"),
                                  (r["n_genres"], "Genres"), (f"{svd['rmse']:.3f}", "SVD hold-out RMSE")]):
        c.markdown(f'<div class="cm-stat"><b>{v}</b><span>{lab}</span></div>', unsafe_allow_html=True)
    st.markdown(f"""
**CONTENT-BASED FILTERING — TF-IDF + Cosine Similarity.** Each movie becomes a vector from its genres, release decade and
shared title keywords; cosine similarity between vectors gives “movies like this”.

**COLLABORATIVE FILTERING — SVD + MovieLens ratings.** Backend: `{svd['backend']}` ({svd['n_factors']} latent factors, biased matrix
factorisation). Hold-out RMSE **{svd['rmse']:.3f}** / MAE {svd['mae']:.3f} on {svd['n_test']:,} held-out ratings from users with ≥3 ratings
(a bias-only baseline scores {svd['rmse_baseline']:.3f}). New visitors have no MovieLens user id, so their history is *folded in* by averaging the
latent vectors of watched movies and finding the closest items. Ratings have no timestamps, so nothing time-based is claimed.
{"" if HAS_SURPRISE else "*Note: `scikit-surprise` isn't installed here, so CineMatch used its built-in NumPy SVD (same model).*"}

**⚖️ COMPARISON — the core of the project.** The two pipelines are implemented separately and never blended on the *Compare Both* page:
content-based reads only movie metadata; collaborative reads only ratings. The page shows each list, the overlap, rank differences,
profile metrics and a leak-free offline evaluation (RMSE for rating prediction; hidden-movie retrieval for top-K), all computed from this dataset.

**PERSONALIZATION — Watch History + Genre Profile.** Your history (most recent first), My List (half weight) and Face-Off picks (half weight)
become a weighted taste profile. Final score = content similarity + SVD similarity + genre match + Bayesian-shrunk rating quality + a small popularity term.

**MOOD ENGINE — Mood → Genre mapping + personalization.** A mood is a hand-written genre weighting (no emotion detection); it's blended with your profile.

**DISCOVERY MODE — Similarity + recommendation diversity.** Familiar = strongest similarity; Explore = MMR diversity re-ranking; Wild = good movies *outside* your genre profile.

**RATING QUALITY.** Averages are shrunk toward the global mean (prior strength 15), so 5.0 from 2 users can't beat 4.6 from hundreds.
""")
    with st.expander("Dataset report"):
        st.json({k: v for k, v in r.items() if k != "genres"})
        st.write("Genres:", ", ".join(r["genres"]))
    with st.expander("Collaborative demo: predicted picks for a real MovieLens user"):
        uid = st.selectbox("MovieLens user id (most active users)", svd["heavy_users"], key="demo_uid")
        for rec in E.user_demo(uid, 6):
            i = E.info_by_id(rec["movieId"])
            st.write(f"**{i['name']}** ({i['year']}) — {rec['why']}")
    st.button("↺ Reset my session (history, list, preferences)", key="reset", on_click=act_reset)


# ─────────────────────────────────────────────────── ⚖️ COMPARE BOTH METHODS
def cmp_grid(recs: list[dict], other_ids: set, score_fmt) -> str:
    cells = ""
    for r in recs:
        info = E.info_by_id(r["movieId"])
        if not info:
            continue
        art = _art(info)
        both = r["movieId"] in other_ids
        tag = '<span class="cm-both-tag">⇄ BOTH</span>' if both else ""
        yr = f' · {info["year"]}' if info["year"] else ""
        cells += (f'<div class="cm-card cm-cc{" both" if both else ""}"><div class="cm-art" style="background-image:{_bg(art["card"], art["fallback"])}">'
                  f'<span class="cm-badge">#{r["rank"]}</span>{tag}<span class="cm-rate">{esc(score_fmt(r))}</span></div>'
                  f'<div class="cm-meta2"><div class="cm-title" title="{esc(info["name"])}">{esc(info["name"])}</div>'
                  f'<div class="cm-sub">{esc(" · ".join(info["genres"][:2]) or "—")}{yr}</div></div></div>')
    return f'<div class="cm-cmp-grid">{cells}</div>'


def bar_pair(title: str, hint: str, cb: float, cf: float, fmt: str = "{:.2f}"):
    top = max(cb, cf, 1e-9)
    st.markdown(f'<div class="cm-cbar"><div class="t">{esc(title)} <small>— {esc(hint)}</small></div>'
                f'<div class="r"><i>CB</i><div class="tr"><div class="f1" style="width:{cb / top * 100:.0f}%"></div></div><span class="v">{fmt.format(cb)}</span></div>'
                f'<div class="r"><i>CF</i><div class="tr"><div class="f2" style="width:{cf / top * 100:.0f}%"></div></div><span class="v">{fmt.format(cf)}</span></div></div>',
                unsafe_allow_html=True)


def cmp_inputs():
    """Select a movie or a MovieLens user; return (cb, cf, ref_genres, query_label, extra) from the TWO separate pipelines."""
    svd, idx, n = _svd(), _rating_index(), int(S.cmp_n)
    if S.cmp_mode == "🎬 By movie":
        st.selectbox("Movie (type to search)", MOVIE_OPTS, key="cmp_movie",
                     format_func=lambda m: f"{E.info_by_id(m)['name']} ({E.info_by_id(m)['year'] or '—'})")
        mid = int(S.cmp_movie)
        info = E.info_by_id(mid)
        cb = content_recs_for_movie(_content(), E.m, mid, n)
        cf = cf_recs_for_movie(svd, E.m, mid, n)
        return cb, cf, set(info["genres"]), f"“{info['name']}”", {"mode": "movie", "mid": mid, "info": info, "idx": idx}
    users = sorted(u for u, (m, r) in idx["by_user"].items() if len(m) >= 15)
    if S.cmp_user not in users:
        S.cmp_user = users[0]
    st.selectbox("MovieLens user (users with ≥15 ratings)", users, key="cmp_user",
                 format_func=lambda u: f"User {u} · {len(idx['by_user'][u][0])} ratings")
    um, ur = idx["by_user"][int(S.cmp_user)]
    cb, seeds = content_recs_for_user(_content(), E.m, svd["id_index"], um, ur, n)
    cf = cf_recs_for_user(svd, E.m, int(S.cmp_user), um, n)
    gl = [g for m in seeds for g in E.info_by_id(m)["genres"]]
    ref = {g for g, _ in pd.Series(gl).value_counts().head(5).items()} if gl else set()
    return cb, cf, ref, f"MovieLens user {S.cmp_user}", {"mode": "user", "seeds": seeds, "um": um, "ur": ur}


def cmp_tables(cb, cf, extra):
    rows_cb, rows_cf = [], []
    for r in cb:
        i = E.info_by_id(r["movieId"])
        if extra["mode"] == "movie":
            shared = [g for g in i["genres"] if g in extra["info"]["genres"]]
            why = f"Shares {', '.join(shared) or 'no genres'}; TF-IDF cosine {r['score']:.2f}"
        else:
            sims = [(float(_content()["sim"][E.idx[r['movieId']], E.idx[s]]), s) for s in extra["seeds"] if s in E.idx]
            best = max(sims)[1]
            why = f"Closest to a movie you rated highly: {E.info_by_id(best)['name']}"
        rows_cb.append({"Rank": r["rank"], "Movie": i["name"], "Cosine similarity": round(r["score"], 3), "# ratings": i["n"], "Why": why})
    for r in cf:
        i = E.info_by_id(r["movieId"])
        if extra["mode"] == "movie":
            st_ = co_rating_stats(extra["idx"], extra["mid"], r["movieId"])
            why = (f"{st_['n_both']} users rated both; {st_['liked_both']} liked both" if st_["n_both"]
                   else "No user rated both — similarity comes from indirect rating patterns")
            rows_cf.append({"Rank": r["rank"], "Movie": i["name"], "Latent score": round(r["score"], 3),
                            "Typical predicted ★ (μ+bᵢ)": round(r["typical_pred"], 2), "# ratings": i["n"], "Evidence in the ratings": why})
        else:
            rows_cf.append({"Rank": r["rank"], "Movie": i["name"], "Predicted ★": round(r["pred"], 2), "# ratings": i["n"],
                            "Why": "SVD prediction μ + bᵤ + bᵢ + pᵤ·qᵢ learned from rating patterns"})
    return pd.DataFrame(rows_cb), pd.DataFrame(rows_cf)


def performance_section():
    section("📐 MODEL PERFORMANCE", "Leak-free offline evaluation on the same per-user hold-out for every method")
    if not S.cmp_eval:
        st.button("▶ Run offline evaluation (≈5 s)", key="cmp_eval_btn", type="primary", on_click=lambda: S.update(cmp_eval=True))
        st.caption("Hides one liked movie per user, builds each method only from the user's training ratings, and checks who finds it.")
        return
    ev = _evaluation()
    r, tk, K = ev["ratings"], ev["topk"], ev["K"]
    st.markdown("**A · Rating prediction error (RMSE, lower is better)**")
    rm = pd.DataFrame([
        {"Method": "Item mean (no personalization)", "RMSE": round(r["item_mean_rmse"], 4)},
        {"Method": "Content-based kNN (TF-IDF similarity-weighted)", "RMSE": round(r["content_rmse"], 4)},
        {"Method": f"Collaborative SVD ({r['svd_backend']})", "RMSE": round(r["svd_rmse"], 4)},
    ])
    st.dataframe(rm, hide_index=True, use_container_width=True)
    best = rm.sort_values("RMSE").iloc[0]["Method"]
    st.caption(f"{r['n_test']:,} held-out ratings; best: {best}. Collaborative SVD also reports a bias-only baseline of {r['svd_bias_rmse']:.4f} — "
               "on this sparse data (~5 ratings/user) the learned factors add only a small gain over biases.")
    st.markdown(f"**B · Finding a hidden liked movie (top-{K}, {ev['n_users']:,} users)**")
    label = {"content": "Content-Based (TF-IDF cosine on liked movies)", "collab_pred": "Collaborative (SVD predicted rating, user folded in)",
             "collab_latent": "Collaborative (SVD latent-space neighbours)", "popular": "Popularity baseline (reference only)"}
    tb = pd.DataFrame([{"Method": label[k], "Hit-rate": f"{v['hit_rate']:.2%} ± {1.96 * v['se']:.2%}",
                        "Mean percentile rank ↓": round(v["mean_pct_rank"], 3), "Catalogue coverage": f"{v['coverage']:.1%}",
                        "Median # ratings of recs": round(v["median_popularity"])} for k, v in tk.items()])
    st.dataframe(tb, hide_index=True, use_container_width=True)
    c, p, l, pop = tk["content"], tk["collab_pred"], tk["collab_latent"], tk["popular"]
    bar_pair("Hit-rate", f"top-{K}, higher is better", c["hit_rate"] * 100, p["hit_rate"] * 100, "{:.2f}%")
    bar_pair("Catalogue coverage", "share of all movies ever recommended", c["coverage"] * 100, p["coverage"] * 100, "{:.1f}%")
    notes = []
    gap = p["hit_rate"] - c["hit_rate"]
    se2 = 1.96 * np.hypot(p["se"], c["se"])
    notes.append(f"Collaborative (SVD predicted rating) hit-rate {p['hit_rate']:.2%} vs content-based {c['hit_rate']:.2%}: "
                 + ("a difference larger than the sampling noise." if abs(gap) > se2 else "within sampling noise — no clear winner."))
    notes.append(f"Collaborative SVD latent neighbours reach percentile rank {l['mean_pct_rank']:.2f} (0.50 = chance), "
                 f"content {c['mean_pct_rank']:.2f}, SVD predicted ratings {p['mean_pct_rank']:.2f}.")
    notes.append(f"Average top-{K} overlap between the two methods is only {ev['overlap_content_vs_pred']:.1%} (predicted-rating CF) / "
                 f"{ev['overlap_content_vs_latent']:.1%} (latent CF): they genuinely recommend different movies.")
    if pop["hit_rate"] > max(c["hit_rate"], p["hit_rate"]):
        notes.append(f"A plain popularity list scores {pop['hit_rate']:.2%} — higher than both personalized methods — but covers only "
                     f"{pop['coverage']:.1%} of the catalogue. On sparse data accuracy and variety pull in opposite directions.")
    notes.append(f"Candidate movies need ≥{ev['min_support']} training ratings for every method; held-out movies outside that set are skipped.")
    st.markdown('<div class="cm-note">' + "<br>".join("• " + esc(n) for n in notes) + "</div>", unsafe_allow_html=True)


def page_compare():
    section("⚖️ COMPARE BOTH METHODS", "CineMatch — Comparative Movie Recommendation System")
    cA, cB = st.columns(2)
    cA.markdown('<div class="cm-meth cb"><h3>🧬 CONTENT-BASED FILTERING</h3><p>Looks only at what a movie <i>is</i>: its genres, decade and title keywords. '
                'No ratings are used.</p><div class="cm-flow">metadata → TF-IDF → cosine similarity</div></div>', unsafe_allow_html=True)
    cB.markdown('<div class="cm-meth cf"><h3>👥 COLLABORATIVE FILTERING</h3><p>Looks only at how people <i>rated</i> movies. Learns latent factors '
                'with SVD; never sees genres or titles.</p><div class="cm-flow">user–movie ratings → SVD → predicted ratings</div></div>', unsafe_allow_html=True)
    c1, c2 = st.columns([1, 3])
    c1.radio("Compare for", ["🎬 By movie", "👤 By MovieLens user"], key="cmp_mode")
    c1.slider("Recommendations per method", 5, 12, key="cmp_n")
    with c2:
        cb, cf, ref, label, extra = cmp_inputs()
    if not cb or not cf:
        st.info("Not enough data to compare for this selection.")
        return
    cmp = compare_lists(cb, cf, E.m, ref)
    infos = [E.info_by_id(r["movieId"]) for r in cb + cf]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos if i], KEY)
    if extra["mode"] == "user":
        st.caption("Content-based profile built from this user's own highest-rated movies: "
                   + ", ".join(E.info_by_id(m)["name"] for m in extra["seeds"][:6]) + "…")
    L, R_ = st.columns(2)
    with L:
        st.markdown(f'<div class="cm-sec"><h3>🧬 CONTENT-BASED RECOMMENDATIONS</h3><span>for {esc(label)} · TF-IDF cosine similarity</span></div>', unsafe_allow_html=True)
        st.markdown(cmp_grid(cb, set(cmp["both"]), lambda r: f"cos {r['score']:.2f}"), unsafe_allow_html=True)
    with R_:
        st.markdown(f'<div class="cm-sec"><h3>👥 COLLABORATIVE FILTERING RECOMMENDATIONS</h3><span>for {esc(label)} · SVD on user ratings</span></div>', unsafe_allow_html=True)
        fmt = (lambda r: f"SVD {r['score']:.2f}") if extra["mode"] == "movie" else (lambda r: f"★ {r['pred']:.2f}")
        st.markdown(cmp_grid(cf, set(cmp["both"]), fmt), unsafe_allow_html=True)
    t_cb, t_cf = cmp_tables(cb, cf, extra)
    with st.expander("🔍 Why each movie was recommended", expanded=True):
        st.markdown("**Content-Based** — explanation comes from the movie's own features")
        st.dataframe(t_cb, hide_index=True, use_container_width=True)
        st.markdown("**Collaborative Filtering** — explanation comes from learned user-rating patterns")
        st.dataframe(t_cf, hide_index=True, use_container_width=True)
        if extra["mode"] == "movie":
            st.caption("Latent score = cosine in the SVD item space × support shrinkage. “Typical predicted ★” = global mean + learned item bias (what SVD expects an average user to give). "
                       "A movie has no single predicted rating without a user — pick “By MovieLens user” for true per-user predicted ratings.")

    section("📊 HEAD-TO-HEAD", "How the two recommendation lists relate")
    nb, no_cb, no_cf = len(cmp["both"]), len(cmp["only_cb"]), len(cmp["only_cf"])
    v, m = st.columns([1, 1])
    with v:
        st.markdown(f'<div class="cm-venn"><div class="c ca"></div><div class="c cb2"></div>'
                    f'<div class="n n1"><b>{no_cb}</b><span>Content only</span></div><div class="n n2"><b>{nb}</b><span>Both</span></div>'
                    f'<div class="n n3"><b>{no_cf}</b><span>Collab. only</span></div></div>'
                    f'<div class="cm-vlab"><span>🧬 Content-Based</span><span>👥 Collaborative</span></div>', unsafe_allow_html=True)
    with m:
        rho = "—" if cmp["spearman"] is None else f"{cmp['spearman']:.2f}"
        s1, s2, s3 = st.columns(3)
        s1.markdown(f'<div class="cm-stat"><b>{nb}/{cmp["n"]}</b><span>Movies in both lists</span></div>', unsafe_allow_html=True)
        s2.markdown(f'<div class="cm-stat"><b>{cmp["jaccard"]:.0%}</b><span>Jaccard overlap</span></div>', unsafe_allow_html=True)
        s3.markdown(f'<div class="cm-stat"><b>{rho}</b><span>Rank correlation (shared)</span></div>', unsafe_allow_html=True)
        st.caption("Overlap is often near zero: the two methods use different information, so differing lists are expected, not an error.")
    names = lambda ids: ", ".join(E.info_by_id(i)["name"] for i in ids) or "—"
    x1, x2, x3 = st.columns(3)
    x1.markdown(f"**🧬 Only Content-Based**\n\n{names(cmp['only_cb'])}")
    x2.markdown(f"**⇄ Recommended by both**\n\n{names(cmp['both'])}")
    x3.markdown(f"**👥 Only Collaborative**\n\n{names(cmp['only_cf'])}")
    st.markdown("**Ranking differences**")
    st.dataframe(cmp["table"], hide_index=True, use_container_width=True)
    pc, pf = cmp["cb_profile"], cmp["cf_profile"]
    ref_txt = "the selected movie's genres" if extra["mode"] == "movie" else "the user's top genres"
    st.markdown("**What kind of movies does each method pick?** (CB = content-based, CF = collaborative)")
    b1, b2 = st.columns(2)
    with b1:
        bar_pair("Genre overlap", f"Jaccard with {ref_txt}", pc["genre_overlap"], pf["genre_overlap"])
        bar_pair("Cross-genre picks", "share with NO genre in common", pc["cross_genre"], pf["cross_genre"], "{:.0%}")
    with b2:
        bar_pair("Popularity", "median # ratings of recommended movies", pc["median_ratings"], pf["median_ratings"], "{:.0f}")
        bar_pair("Genres covered", "distinct genres in the list", pc["genres_covered"], pf["genres_covered"], "{:.0f}")
    st.markdown(
        '<div class="cm-note"><b>Strengths.</b> Content-based: explainable, works for brand-new or rarely-rated movies (cold start), stays on-topic, '
        'but only knows genres/era/title words, so it keeps recommending look-alikes (sequels, same genre mix). '
        'Collaborative: discovers taste patterns no metadata describes and can cross genres, but needs rating data, '
        'leans toward popular movies, and is weak where ratings are sparse — as here.</div>', unsafe_allow_html=True)
    performance_section()


# ────────────────────────────────────────────────────────────────────── pages
def page_home():
    hero(todays_pick())
    st.markdown('<div class="cm-banner" style="margin-top:1rem"><h2>⚖️ Content-Based vs Collaborative Filtering</h2>'
                '<p>See what each method recommends for the same movie — side by side, with overlap, ranking differences and evaluation metrics.</p></div>',
                unsafe_allow_html=True)
    st.button("⚖️ Open Compare Both", key="home_cmp", on_click=act_goto, args=(P_CMP,), type="primary")
    if not S.watch_history:
        empty_home()
        movie_row("🔥 POPULAR MOVIES", E.trending(ctx(), ROW), "pop", "Most-rated, well-rated movies")
        mood_section()
        section("🎲 SURPRISE ME")
        st.button("🎲 SURPRISE ME", key="home_surprise", on_click=act_surprise, type="primary")
        section("🧭 EXPLORE GENRES")
        top = [g for g, _ in E.m.explode("genre_list")["genre_list"].value_counts().head(6).items()]
        for c, g in zip(st.columns(6), top):
            c.button(genre_label(g), key=f"home_g_{g}", on_click=act_goto, args=(P_EXPL, g), use_container_width=True)
        return
    history_strip()
    movie_row("🔥 TRENDING FOR YOU", E.trending(ctx(), ROW), "trend", "Popularity × rating quality × your genres")
    mood_section()
    personalised_rows()
    section("🎲 SURPRISE ME")
    st.button("🎲 SURPRISE ME", key="home_surprise", on_click=act_surprise, type="primary")
    movie_row("🎯 YOU MIGHT HAVE MISSED", E.missed(ctx(), S.recent_recommendations[-60:], ROW), "missed",
              "Fits your taste, but hasn't appeared in the rows above")
    movie_row("🤖 COLLABORATIVE FILTERING RECOMMENDATIONS", E.collaborative(ctx(), ROW), "collab",
              "SVD latent-space neighbours of your watch history · see ⚖️ Compare Both for the head-to-head")


def page_discover():
    surprise_block()
    faceoff_block()
    night_block()
    double_block()
    bedtime_block()
    movie_row("🕵️ HIDDEN GEMS", E.hidden_gems(ctx(), ROW), "gems", "Well rated, fewer ratings than the mainstream, relevant to you", rows=1)


def page_explore():
    genre_explorer()
    world_block()


def page_space():
    c1, c2 = st.columns(2)
    with c1:
        profile_block()
    with c2:
        taste_block()
    evolution_block()
    milestones_block()
    list_block()
    history_block()


def act_test_tmdb():
    k = get_api_key(S.get("tmdb_key"))
    S.tmdb_test = test_connection(k) if k else (False, "Paste your TMDB API key first.")


def tmdb_setup():
    """Real posters need a TMDB key. Shown open until a working key is present; never stored on disk."""
    ok_now = bool(KEY) and not PU.last_error
    label = "🎞️ Posters: connected ✓" if ok_now else "🎞️ Show real movie posters (TMDB key)"
    with st.expander(label, expanded=not KEY):
        if not KEY:
            st.caption("Without a key CineMatch draws generated artwork. Paste your free TMDB v3 API key to load real posters.")
        st.text_input("TMDB API key", key="tmdb_key", type="password", placeholder="paste your v3 API key",
                      help="Kept only in this browser session. To make it permanent, put TMDB_API_KEY in .streamlit/secrets.toml")
        st.radio("🛡️ Artwork filter", ART_OPTS, key="art_level", horizontal=True,
                 help="Strict (default): real posters only for movies TMDB rates G / PG / PG-13. Everything else — including unrated — gets a clean generated card.")
        st.button("Test connection", key="tmdb_test_btn", on_click=act_test_tmdb)
        res = S.get("tmdb_test")
        if res:
            (st.success if res[0] else st.error)(res[1])
        elif KEY and PU.last_error:
            st.warning(PU.last_error)
        return st.empty()
    return None


def fill_art_stats(slot):
    """Summarise artwork sources for the cards drawn on this page (called at the end of the run)."""
    if slot is None or not KEY:
        return
    s = PU.ART_STATS
    uniq = lambda k: len(set(s[k]))
    slot.caption(f"This page → official posters: {uniq('poster') + uniq('alt_poster')} · scene images: {uniq('scene')} · "
                 f"generated cards: {uniq('generated')} · age-rated (hidden): {uniq('hidden_18')}"
                 + (f"  (no TMDB image: {', '.join(sorted(set(s['generated']))[:6])})" if s["generated"] else ""))


# ───────────────────────────────────────────────────────────── login / sign up
def _enter(username: str | None):
    """Start a session: a named account (restoring saved state) or a guest."""
    S.user, S.guest = username, username is None
    if username:
        for k, v in auth.load_state(username).items():
            S[k] = v
        S.last_saved = ""
    S.auth_msg = None
    S.page = P_HOME


def act_login():
    ok, msg = auth.verify_user(S.get("li_user", ""), S.get("li_pass", ""))
    if ok:
        S.li_pass = ""
        _enter(msg)
        toast(f"👋 Welcome back, {msg}")
    else:
        S.auth_msg = ("error", msg)


def act_signup():
    ok, msg = auth.create_user(S.get("su_user", ""), S.get("su_pass", ""), S.get("su_pass2", ""))
    if ok:
        user = S.su_user.strip()
        S.su_pass = S.su_pass2 = ""
        _enter(user)
        toast(msg)
    else:
        S.auth_msg = ("error", msg)


def act_guest():
    _enter(None)


def act_logout():
    if S.user:
        auth.save_state(S.user, S)
    act_reset()
    S.user, S.guest, S.last_saved, S.auth_msg = None, False, "", None


def autosave():
    """Persist the signed-in user's watch history / list / preferences whenever they change."""
    if not S.user:
        return
    snap = {k: S.get(k) for k in auth.PERSIST_KEYS}
    blob = str(sorted(snap.items(), key=lambda x: x[0]))
    if blob != S.last_saved:
        try:
            auth.save_state(S.user, snap)
            S.last_saved = blob
        except Exception:
            pass  # never let a disk problem crash the UI


def auth_page():
    top = E.m.sort_values("n_ratings", ascending=False).head(14)
    infos = [E.info(int(i)) for i in top.index]
    prefetch([(i["tmdbId"], i["name"], i["year"]) for i in infos], KEY)
    tiles = "".join(f'<div class="cm-tile"><div class="cm-art" style="background-image:{_bg(_art(i)["card"], _art(i)["fallback"])}"></div></div>'
                    for i in infos)
    st.markdown(f'<div class="cm-collage">{tiles}</div>', unsafe_allow_html=True)
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        st.markdown('<div class="cm-auth"><div class="cm-logo" style="font-size:2.6rem">🎬 CineMatch</div>'
                    '<div class="cm-tag" style="font-size:1rem">Your watch history. Your next movie.</div>'
                    '<div class="cm-tag" style="font-size:.74rem;letter-spacing:1.5px;color:#b9b0ff;margin-top:.3rem">COMPARATIVE MOVIE RECOMMENDATION SYSTEM</div></div>',
                    unsafe_allow_html=True)
        tab_in, tab_up = st.tabs(["🔑 Log in", "✨ Sign up"])
        with tab_in:
            st.text_input("Username", key="li_user")
            st.text_input("Password", key="li_pass", type="password")
            st.button("Log in", key="btn_login", type="primary", use_container_width=True, on_click=act_login)
        with tab_up:
            st.text_input("Choose a username", key="su_user", help="3–20 letters, numbers or underscore")
            st.text_input("Password (min 6 characters)", key="su_pass", type="password")
            st.text_input("Confirm password", key="su_pass2", type="password")
            st.button("Create my account", key="btn_signup", type="primary", use_container_width=True, on_click=act_signup)
        if S.auth_msg:
            st.error(S.auth_msg[1])
        st.markdown('<div class="cm-or">or</div>', unsafe_allow_html=True)
        st.button("🍿 Continue as guest", key="btn_guest", use_container_width=True, on_click=act_guest)
        st.caption("Accounts are stored locally on this machine (hashed passwords) and save your watch history, list and preferences. "
                   "Guests start fresh each session.")


def footer(slot=None):
    fill_art_stats(slot)
    st.markdown('<div class="cm-footer"><b>🎬 CineMatch</b> — Comparative Movie Recommendation System<br>'
                'Ratings data: MovieLens · Content-Based Filtering (TF-IDF) vs Collaborative Filtering (SVD)<br>'
                '<span>This product uses the TMDB API but is not endorsed or certified by TMDB.</span></div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────── main
def main():
    st.markdown(CSS, unsafe_allow_html=True)
    if not (S.user or S.guest):
        auth_page()
        return
    c1, c2, c3 = st.columns([2, 3, 1])
    c1.markdown('<div class="cm-brand"><div class="cm-logo">🎬 CineMatch</div>'
                '<div class="cm-tag">Your watch history. Your next movie.</div>'
                '<div class="cm-tag" style="font-size:.74rem;letter-spacing:1.5px;color:#b9b0ff">COMPARATIVE MOVIE RECOMMENDATION SYSTEM</div></div>', unsafe_allow_html=True)
    c2.text_input("Search", key="search_q", placeholder="🔎  Search a title, or try “funny”, “animation”, “scary”…",
                  label_visibility="collapsed")
    c3.markdown(f'<div class="cm-userchip">👤 {esc(S.user or "Guest")}</div>', unsafe_allow_html=True)
    c3.button("Log out" if S.user else "Sign in / up", key="btn_logout", on_click=act_logout, use_container_width=True)
    st.radio("Navigate", PAGES, key="page", horizontal=True, label_visibility="collapsed")
    PU.reset_art_stats()
    slot = tmdb_setup()
    detail_panel()
    if S.search_q.strip():
        search_results()
        footer(slot)
        autosave()
        return
    {P_HOME: page_home, P_CMP: page_compare, P_DISC: page_discover, P_EXPL: page_explore,
     P_SPACE: page_space, P_HOW: how_it_works}[S.page]()
    footer(slot)
    autosave()


main()
