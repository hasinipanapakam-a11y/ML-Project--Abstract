# 🎬 CineMatch — Comparative Movie Recommendation System
**Your watch history. Your next movie.**

> A movie recommendation platform that implements **Content-Based Filtering** and **Collaborative Filtering** as two
> separate pipelines and **directly compares** the recommendations they produce.

## 0. The central feature: ⚖️ Compare Both Methods
```
Content-Based:  movie metadata (genres, decade, title keywords) -> TF-IDF -> cosine similarity -> recommendations
Collaborative:  user-movie ratings -> SVD / matrix factorisation -> predicted ratings / latent scores -> recommendations
                      Selected movie (or MovieLens user)
                       |                             |
                 Content-Based                 Collaborative
                       +-------------+---------------+
                              DIRECT COMPARISON
              side-by-side cards - overlap (Venn) - rank differences - score tables
              profile metrics (genre overlap, popularity, cross-genre) - offline evaluation
```
Open the **⚖️ Compare Both** page (or press **⚖️ Compare** in any movie's detail view), pick a movie *or* a real MovieLens user, and see:
Content-Based Recommendations and Collaborative Filtering Recommendations side by side (green glow = recommended by both), the explanation for
every pick, the Venn overlap, rank shifts, Jaccard overlap, rank correlation, and an offline evaluation:

* **RMSE** (rating prediction): item-mean baseline vs content-based kNN vs SVD, on the same per-user hold-out.
* **Top-K retrieval**: one liked movie is hidden per user; each method is built only from that user's *training* ratings (SVD factors are
  trained on the training split only — no leakage). Reports hit-rate ± 95% CI, mean percentile rank, catalogue coverage, popularity, overlap.

### What the evaluation shows on *this* dataset (4,464 movies · 200k ratings · ~4.9 ratings/user)
Numbers are computed live in the app; one run produced (top-10, 4,682 users): content hit-rate 1.15% · SVD-predicted-rating 1.73% ·
SVD latent neighbours 1.28% · popularity baseline 3.4% (covering 0.3% of the catalogue). RMSE: item mean 0.961 · content kNN 0.909 · SVD 0.898.
Top-10 lists of the two methods overlap by only ~0.2%. Takeaways: SVD predicts ratings slightly better, the methods recommend different movies,
and sparsity limits collaborative filtering (plain "latent cosine" between two movies is at chance level here — shown honestly in the app).

**Honest note on the CSVs:** they contain only `genres` and `title` (no keywords, cast or plot). The content model therefore uses genres,
release decade and shared title keywords. Plot overviews exist only via the optional TMDB API and are not used for similarity.

CineMatch is a movie discovery and recommendation app built with Streamlit. It blends content-based filtering,
SVD collaborative filtering and watch-history personalization, with mood, surprise, face-off and discovery features
on a cinematic OTT-style interface.

## Accounts, login & posters
* **Log in / Sign up / Continue as guest** on first load. Accounts live in a local SQLite file (`data/cinematch_users.db`, created on first
  sign-up) with salted PBKDF2-SHA256 password hashes; a signed-in user's watch history, My List, moods and preferences are saved automatically
  and restored at next login. It is a local prototype login (no e-mail verification or password reset). Guests start fresh each session.
* **Posters:** official TMDB poster first, then TMDB's alternate posters (English first); if a movie has no poster, its scene/backdrop image is used; if neither exists, a generated cinematic
  card. The key is read from `.streamlit/secrets.toml` (included, git-ignored), the `TMDB_API_KEY` env var, or the in-app **🎞️ Posters** panel
  (with a **Test connection** button). **🛡️ Artwork filter** (Posters panel): **Strict** (default) shows real posters/scenes only for movies TMDB rates G / PG / PG-13 (or equivalent) — anything R, 18+, India-A, adult-flagged or without rating data gets a clean generated card; **Standard** hides R/18+ only; **Off** shows everything. A status line shows how many cards got posters, scenes or generated art on each page. Treat that key as private and rotate it if it was ever shared.

## 1. Other features
| Area | What it does |
|---|---|
| Watch History | ✓ marks a movie watched (most recent first, de-duplicated, max 20; click ✓ again to remove) |
| Because you watched… | Content-similar movies to your latest watch |
| Made for your watch history | One combined taste profile across *all* watched movies (excludes watched + My List) |
| Genre personalization | "Because you like Animation / Matching your taste" — computed from real history |
| 🎭 Mood | 10 viewing moods → genre weights, blended with your profile |
| 🎲 Surprise Me | One unseen, well-rated pick; never repeats within a session |
| ⚔️ Pick One | Face-off; your pick is a session-only signal (half weight) — nothing is retrained |
| 🧭 Discovery Mode | Familiar / Explore (MMR diversity) / Wild (outside your genre profile) |
| 🕵️ Hidden Gems, 🔥 Trending for you, 🧩 Mix it up, 🎯 You might have missed | Quality × evidence × relevance, not raw averages |
| 🍿 Movie Night, 🎬 Double Feature, 🌙 One movie before bed | Situation-based picks |
| 📊 Taste, 🧠 Profile, 📈 Evolution, 🏆 Milestones | Derived only from your actions |
| 🔎 Search | Title, partial title and genre keywords ("funny", "scary", "sci fi") — no LLM needed |
| 🎞️ Detail view | Backdrop, poster, overview, TMDB info, Watched / My List / More like this |
| 💡 "Why this pick?" | Each card's explanation is generated from the signal that actually produced it |

## 2. Dataset files (`data/`)
Inspected rather than assumed:

| File | Rows | Columns |
|---|---|---|
| `movies.csv` | 4,464 | `movieId, title, genres, tmdbId` |
| `ratings.csv` | 200,000 | `userId, movieId, rating` (0.5–5.0) — **no timestamp column** |
| `links.csv` | 4,464 | `movieId, imdbId, tmdbId` |

41,184 users · 18 genres · no duplicate rows · every rating maps to a movie · one movie (Dune, 2000) has no `tmdbId`.
Files are joined on `movieId` only (never on title). `IMAX` and `(no genres listed)` are dropped from genre lists
(IMAX is a format). There is no language/country column, so "Explore the World" uses TMDB metadata only.

## 3. Algorithms
* **Content-based** — TF-IDF over genres + release decade + shared title keywords, cosine similarity (`src/content_based.py`).
* **Collaborative** — biased SVD on `userId/movieId/rating` using **Surprise SVD**; if `scikit-surprise` can't be installed,
  an equivalent NumPy FunkSVD is used automatically. Evaluated on a per-user hold-out (RMSE/MAE shown in *How it works*,
  with a bias-only baseline for context). New visitors are "folded in" via the latent vectors of movies they watched.
* **Hybrid scoring** — content similarity + SVD similarity + genre match + Bayesian-shrunk rating quality + popularity,
  then MMR diversity re-ranking and a per-franchise cap (`src/recommender.py`).
* **Rating quality** — `(v/(v+15))·avg + (15/(v+15))·global_mean`, so 5.0 from 2 users cannot beat 4.6 from hundreds.

## 4. Installation
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
`scikit-surprise` compiles C code; if it fails (common on new Python versions/Windows without build tools) just remove
it from `requirements.txt` — the app falls back to the built-in SVD.

## 5. Run
```bash
streamlit run app.py
```
First launch trains the models (~10–20 s); they are cached with `st.cache_resource` and not rebuilt on clicks.

## 6. TMDB artwork
Without a key everything works with generated cinematic artwork. For real posters/backdrops/overviews, either:
```toml
# .streamlit/secrets.toml   (git-ignored; see secrets.toml.example)
TMDB_API_KEY = "your_v3_api_key"
```
or `export TMDB_API_KEY=your_v3_api_key`. **Never commit the key.**
Artwork order: MovieLens `tmdbId` → verify title/year → TMDB title search (validated, never blindly `results[0]`) →
poster → backdrop → generated fallback. Failures never crash the app; after a network error TMDB is skipped for 45 s.

## 7. Structure
```
app.py                  UI, session state, all sections
src/utils.py            loading, cleaning, joins, rating-quality prior
src/content_based.py    build_content_model, get_content_recommendations
src/collaborative.py    build_svd_model, get_svd_recommendations
src/recommender.py      hybrid engine + every feature's ranking logic
src/personalization.py  taste stats, profile, evolution, milestones, mood maps
src/poster_utils.py     TMDB client, validation, caching, generated fallback art
src/theme.py            CSS
src/compare.py          the two pipelines side by side + overlap/ranking + offline evaluation
tests/test_engine.py    Streamlit-free tests (python tests/test_engine.py)
```

## 8. Recommendation pipeline
`session signals (history, list, face-off, onboarding)` → weighted seeds → content / SVD / genre signals → score
(mode weights) → gates (mood, hidden-gem range) → exclusions → MMR + franchise cap → recs with truthful `why` text.

## 9. Known limitations
* Session-only state (no database): history resets when the session ends.
* Ratings have no timestamps, so nothing time-based is modeled.
* Data is sparse (~4.9 ratings/user), so SVD gives a modest signal; it carries less weight than content similarity.
* Mood → genre maps are hand-written heuristics, not emotion detection.
* "Average rating" in *Your Taste* is the community rating of watched movies — users don't rate inside the app.
* Explore the World needs a TMDB key and samples the 120 most-rated movies.
* Layout was built for Streamlit's column grid + CSS wrapping; very old Streamlit versions may differ slightly.
