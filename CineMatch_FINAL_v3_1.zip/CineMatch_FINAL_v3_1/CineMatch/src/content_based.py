"""Content-based filtering: TF-IDF over genres/era/title keywords + cosine similarity."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd
from scipy.sparse import hstack
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.preprocessing import normalize

_TITLE_STOP = set(ENGLISH_STOP_WORDS) | {"movie", "film", "story", "part"}


def _genre_doc(row) -> str:
    toks = [g.lower().replace("-", "_") for g in row["genre_list"]]
    # genres are the main signal; repeat so they dominate the era token
    toks = toks * 2
    if not np.isnan(row["year"]):
        toks.append(f"decade_{int(row['year']) // 10 * 10}")
    return " ".join(toks) or "nogenre"


def _title_doc(name: str) -> str:
    words = re.findall(r"[a-z]{3,}", name.lower())
    return " ".join(w for w in words if w not in _TITLE_STOP)


def build_content_model(movies: pd.DataFrame, title_weight: float = 0.45) -> dict:
    """Return {'sim': dense float32 cosine matrix, 'matrix': sparse TF-IDF, ...}.

    Rows are aligned with `movies` (reset index order).
    """
    movies = movies.reset_index(drop=True)
    gdocs = movies.apply(_genre_doc, axis=1)
    tdocs = movies["name"].map(_title_doc)
    gv = TfidfVectorizer(token_pattern=r"[A-Za-z0-9_]+", sublinear_tf=True)
    G = gv.fit_transform(gdocs)
    tv = TfidfVectorizer(min_df=2, sublinear_tf=True)  # only keywords shared by >=2 titles
    try:
        T = tv.fit_transform(tdocs)
    except ValueError:  # tiny dataset: no shared title words
        T = None
    X = hstack([G, title_weight * T]).tocsr() if T is not None else G.tocsr()
    X = normalize(X)
    sim = (X @ X.T).toarray().astype(np.float32)
    np.fill_diagonal(sim, 1.0)
    return {"sim": sim, "matrix": X, "ids": movies["movieId"].to_numpy(), "n_features": X.shape[1]}


def find_movie_index(movies: pd.DataFrame, title: str) -> int | None:
    """Safe title lookup (exact, then unique-ish substring). None if unknown."""
    if not isinstance(title, str) or not title.strip():
        return None
    t = title.strip().lower()
    for col in ("title", "name"):
        hit = movies.index[movies[col].str.lower() == t]
        if len(hit):
            return int(hit[0])
    hit = movies.index[movies["name"].str.lower().str.contains(re.escape(t), na=False)]
    if len(hit):
        return int(movies.loc[hit, "n_ratings"].idxmax())
    return None


def get_content_recommendations(model: dict, movies: pd.DataFrame, title: str, n: int = 10,
                                exclude_ids=()) -> pd.DataFrame:
    """Movies most similar to `title`. Excludes the movie itself and `exclude_ids`.

    Returns an empty frame (never raises) for unknown titles.
    """
    movies = movies.reset_index(drop=True)
    i = find_movie_index(movies, title)
    if i is None:
        return movies.iloc[0:0].assign(similarity=[])
    s = model["sim"][i].copy()
    s[i] = -1
    skip = movies["movieId"].isin(set(exclude_ids)).to_numpy()
    s[skip] = -1
    top = np.argsort(-s)[: n * 3]
    out = movies.iloc[top].assign(similarity=s[top])
    out = out[out["similarity"] > 0].drop_duplicates("movieId").head(n)
    return out
