"""Collaborative filtering: SVD matrix factorisation (Surprise, with a NumPy/SciPy fallback).

Both backends are normalised into the same plain-array bundle so the rest of the
app (and the RMSE evaluation) is backend-agnostic:

    prediction(u, i) = mu + bu[u] + bi[i] + P[u] . Q[i]
"""
from __future__ import annotations

import numpy as np
import pandas as pd

try:  # Surprise is the primary backend
    from surprise import SVD, Dataset, Reader
    from surprise.model_selection import train_test_split as _sp_split
    HAS_SURPRISE = True
except Exception:  # pragma: no cover - depends on environment
    HAS_SURPRISE = False

N_FACTORS = 20
SUPPORT_K = 40.0  # items with few ratings get unreliable latent vectors -> shrink their similarity


def _arrays_from_surprise(algo, movie_ids: np.ndarray) -> dict:
    ts = algo.trainset
    nf = algo.qi.shape[1]
    Q = np.zeros((len(movie_ids), nf), dtype=np.float32)
    bi = np.zeros(len(movie_ids), dtype=np.float32)
    for k, mid in enumerate(movie_ids):
        try:
            inner = ts.to_inner_iid(int(mid))
        except ValueError:
            continue
        Q[k], bi[k] = algo.qi[inner], algo.bi[inner]
    user_index = {int(ts.to_raw_uid(u)): u for u in ts.all_users()}
    return {"mu": float(ts.global_mean), "bu": algo.bu.astype(np.float32),
            "P": algo.pu.astype(np.float32), "user_index": user_index, "Q": Q, "bi": bi}


def _arrays_from_numpy(train: pd.DataFrame, movie_ids: np.ndarray, k: int = N_FACTORS,
                       epochs: int = 20, lr: float = 0.01, reg: float = 0.15, batch: int = 512,
                       seed: int = 42) -> dict:
    """Fallback FunkSVD (biased matrix factorisation by mini-batch SGD) in pure NumPy.

    Same model Surprise's SVD fits: r_hat = mu + bu + bi + p_u . q_i
    """
    rng = np.random.default_rng(seed)
    mu = float(train["rating"].mean())
    users = train["userId"].astype(int).unique()
    user_index = {int(u): n for n, u in enumerate(users)}
    item_index = {int(m): n for n, m in enumerate(movie_ids)}
    ui = train["userId"].map(user_index).to_numpy()
    ii = train["movieId"].map(item_index).to_numpy()
    r = train["rating"].to_numpy(dtype=np.float32)
    bu = np.zeros(len(users), np.float32)
    bi = np.zeros(len(movie_ids), np.float32)
    P = rng.normal(0, 0.1, (len(users), k)).astype(np.float32)
    Q = rng.normal(0, 0.1, (len(movie_ids), k)).astype(np.float32)
    n = len(r)
    for _ in range(epochs):
        order = rng.permutation(n)
        for s0 in range(0, n, batch):
            sel = order[s0:s0 + batch]
            u, i, y = ui[sel], ii[sel], r[sel]
            pu, qi = P[u], Q[i]
            err = (y - (mu + bu[u] + bi[i] + np.sum(pu * qi, axis=1)))[:, None]
            np.add.at(bu, u, lr * (err[:, 0] - reg * bu[u]))
            np.add.at(bi, i, lr * (err[:, 0] - reg * bi[i]))
            np.add.at(P, u, lr * (err * qi - reg * pu))
            np.add.at(Q, i, lr * (err * pu - reg * qi))
    return {"mu": mu, "bu": bu, "P": P, "user_index": user_index, "Q": Q, "bi": bi}


def _rmse_mae(arr: dict, test: pd.DataFrame, id_index: dict, factors: bool = True) -> tuple[float, float]:
    preds = np.empty(len(test))
    for n, (u, m) in enumerate(zip(test["userId"].to_numpy(), test["movieId"].to_numpy())):
        p = arr["mu"] + arr["bi"][id_index[int(m)]]
        ui = arr["user_index"].get(int(u))
        if ui is not None:
            p += arr["bu"][ui]
            if factors:
                p += arr["P"][ui] @ arr["Q"][id_index[int(m)]]
        preds[n] = min(5.0, max(0.5, p))
    err = preds - test["rating"].to_numpy()
    return float(np.sqrt(np.mean(err ** 2))), float(np.mean(np.abs(err)))


def holdout_split(df: pd.DataFrame, seed: int = 42) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Per-user hold-out shared by every evaluation in the app (SVD RMSE, content kNN RMSE, top-K tests).

    Users with >=3 ratings give ~20% (min 1) of their ratings to the test set; users with fewer stay entirely
    in train. (A plain random split would put mostly never-seen users in test, where no collaborative signal
    can exist.)
    """
    shuf = df.sample(frac=1.0, random_state=seed)
    n_u = shuf.groupby("userId")["rating"].transform("size")
    rank = shuf.groupby("userId").cumcount()
    is_test = (n_u >= 3) & (rank < np.maximum(1, np.round(0.2 * n_u)))
    return shuf[~is_test], shuf[is_test]


def build_svd_model(ratings: pd.DataFrame, movie_ids, seed: int = 42) -> dict:
    """Train SVD, evaluate on a per-user hold-out, then refit on all ratings.

    Returns a bundle with factors, biases, per-user hold-out RMSE/MAE and backend name.
    """
    movie_ids = np.asarray(movie_ids)
    id_index = {int(m): n for n, m in enumerate(movie_ids)}
    df = ratings[["userId", "movieId", "rating"]]
    train_df, test_df = holdout_split(df, seed)
    backend = "numpy-svd"
    try:
        if not HAS_SURPRISE:
            raise ImportError("scikit-surprise not installed")
        reader = Reader(rating_scale=(0.5, 5.0))
        eval_algo = SVD(n_factors=N_FACTORS, n_epochs=30, lr_all=0.007, reg_all=0.1, random_state=seed)
        eval_algo.fit(Dataset.load_from_df(train_df, reader).build_full_trainset())
        arr_eval_ref = _arrays_from_surprise(eval_algo, movie_ids)
        rmse, mae = _rmse_mae(arr_eval_ref, test_df, id_index)
        full = SVD(n_factors=N_FACTORS, n_epochs=30, lr_all=0.007, reg_all=0.1, random_state=seed)
        full.fit(Dataset.load_from_df(df, reader).build_full_trainset())
        arr = _arrays_from_surprise(full, movie_ids)
        backend = "surprise-svd"
    except Exception:
        arr_eval_ref = _arrays_from_numpy(train_df, movie_ids)
        rmse, mae = _rmse_mae(arr_eval_ref, test_df, id_index)
        arr = _arrays_from_numpy(df, movie_ids)
    Q = arr["Q"]
    rmse_base, _ = _rmse_mae(arr_eval_ref, test_df, id_index, factors=False)
    norms = np.linalg.norm(Q, axis=1, keepdims=True)
    support = ratings.groupby("movieId").size().reindex(movie_ids).fillna(0).to_numpy()
    Qe = arr_eval_ref["Q"]
    sup_tr = train_df.groupby("movieId").size().reindex(movie_ids).fillna(0).to_numpy()
    eval_Qn = Qe / np.maximum(np.linalg.norm(Qe, axis=1, keepdims=True), 1e-9)
    arr.update(Qn=Q / np.maximum(norms, 1e-9), movie_ids=movie_ids, id_index=id_index,
               shrink=(support / (support + SUPPORT_K)).astype(np.float32),
               eval_Q=Qe, eval_bi=arr_eval_ref["bi"], eval_mu=arr_eval_ref["mu"], eval_Qn=eval_Qn, eval_shrink=(sup_tr / (sup_tr + SUPPORT_K)).astype(np.float32),
               rmse=rmse, mae=mae, rmse_baseline=rmse_base, backend=backend, n_train=len(train_df), n_test=len(test_df),
               n_factors=Q.shape[1])
    return arr


def fold_in_scores(Q: np.ndarray, bi: np.ndarray, mu: float, rated_idx: np.ndarray, ratings: np.ndarray,
                   lam: float = 1.0) -> np.ndarray:
    """Predicted rating for every movie for a user who is NOT in the training data.

    Solves a ridge regression for the user's latent vector p from their own ratings (Q fixed), then
    predicts  mu + b_i + q_i . p  -- the same SVD prediction rule, with p estimated on the fly.
    """
    Qs = Q[rated_idx]
    y = np.asarray(ratings, float) - mu - bi[rated_idx]
    p = np.linalg.solve(Qs.T @ Qs + lam * np.eye(Q.shape[1]), Qs.T @ y)
    return mu + bi + Q @ p


def predict_user_ratings(model: dict, user_id: int) -> np.ndarray | None:
    """Predicted rating for every movie for a known MovieLens user (None if unknown)."""
    u = model["user_index"].get(int(user_id))
    if u is None:
        return None
    p = model["mu"] + model["bu"][u] + model["bi"] + model["Q"] @ model["P"][u]
    return np.clip(p, 0.5, 5.0)


def get_svd_recommendations(model: dict, movies: pd.DataFrame, seed_movie_ids=(), user_id=None,
                            n: int = 10, exclude_ids=()) -> pd.DataFrame:
    """Collaborative recommendations.

    * known `user_id`  -> highest predicted ratings for that MovieLens user
    * `seed_movie_ids` -> movies closest to the seeds in SVD latent space
      (items rated alike by the same users), a cold-start "fold-in".
    """
    movies = movies.reset_index(drop=True)
    score = None
    if user_id is not None:
        score = predict_user_ratings(model, user_id)
    if score is None and len(seed_movie_ids):
        idx = [model["id_index"][int(m)] for m in seed_movie_ids if int(m) in model["id_index"]]
        if idx:
            v = model["Qn"][idx].mean(axis=0)
            v = v / max(np.linalg.norm(v), 1e-9)
            score = (model["Qn"] @ v) * model["shrink"]
            score[idx] = -9
    if score is None:
        return movies.iloc[0:0].assign(svd_score=[])
    score = np.array(score, dtype=float)
    score[movies["movieId"].isin(set(exclude_ids)).to_numpy()] = -9
    top = np.argsort(-score)[:n]
    return movies.iloc[top].assign(svd_score=score[top])
