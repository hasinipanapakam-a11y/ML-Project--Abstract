"""Cinematic OTT styling for CineMatch (injected once via st.markdown)."""

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@700;800&display=swap');
:root{--bg:#0d1020;--bg2:#151a30;--card:#171c36;--line:rgba(255,255,255,.08);--txt:#e8eaf6;--mut:#9aa0c3;
--acc:#8b7cff;--acc2:#4fc3ff;--glow:rgba(120,100,255,.28);}
html,body,[class*="css"],.stApp{font-family:'Inter',system-ui,sans-serif;color:var(--txt);}
.stApp{background:radial-gradient(1100px 600px at 12% -8%,rgba(110,90,255,.22),transparent 60%),
radial-gradient(900px 520px at 100% 0%,rgba(40,170,255,.14),transparent 55%),
linear-gradient(180deg,#0d1020 0%,#0b0e1c 100%);}
header[data-testid="stHeader"]{background:transparent;}
#MainMenu,footer,[data-testid="stToolbar"],[data-testid="stSidebar"],[data-testid="collapsedControl"]{display:none!important;}
.block-container{max-width:1500px;padding:1.2rem 2rem 4rem;}
div[data-testid="stMarkdownContainer"],div[data-testid="stElementContainer"],div[data-testid="element-container"]{overflow:visible!important;}

/* responsive columns: wrap instead of crushing */
div[data-testid="stHorizontalBlock"]{flex-wrap:wrap;row-gap:.9rem;}
div[data-testid="stColumn"],div[data-testid="column"]{min-width:150px!important;}
div[data-testid="stColumn"] div[data-testid="stColumn"],div[data-testid="column"] div[data-testid="column"]{min-width:0!important;}
div[data-testid="stColumn"] div[data-testid="stHorizontalBlock"],div[data-testid="column"] div[data-testid="stHorizontalBlock"]{flex-wrap:nowrap;gap:.35rem;row-gap:.35rem;}

/* brand */
.cm-brand{display:flex;flex-direction:column;gap:2px;padding-top:.2rem;}
.cm-logo{font-family:'Playfair Display',serif;font-size:2.1rem;font-weight:800;letter-spacing:.5px;
background:linear-gradient(90deg,#fff,#b9b0ff 55%,#7fd4ff);-webkit-background-clip:text;background-clip:text;color:transparent;}
.cm-tag{color:var(--mut);font-size:.9rem;letter-spacing:.4px;}
div[data-testid="stTextInput"] input{background:rgba(255,255,255,.06);border:1px solid var(--line);border-radius:999px;
color:var(--txt);padding:.65rem 1.1rem;}
div[data-testid="stTextInput"] input:focus{border-color:var(--acc);box-shadow:0 0 0 3px var(--glow);}

/* nav pills (st.radio, horizontal) */
div[data-testid="stRadio"] div[role="radiogroup"]{gap:.4rem;flex-wrap:wrap;}
div[data-testid="stRadio"] label{background:rgba(255,255,255,.05);border:1px solid var(--line);border-radius:999px;
padding:.35rem .95rem;cursor:pointer;transition:all .18s;}
div[data-testid="stRadio"] label:hover{background:rgba(139,124,255,.18);}
div[data-testid="stRadio"] label>div:first-child{display:none;}
div[data-testid="stRadio"] label:has(input:checked){background:linear-gradient(135deg,#7b6cff,#4aa8ff);border-color:transparent;
box-shadow:0 6px 22px var(--glow);}
div[data-testid="stRadio"] label p{font-size:.88rem;font-weight:600;margin:0;}

/* buttons */
.stButton>button{border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.06);color:var(--txt);
font-weight:600;padding:.25rem .5rem;min-height:2.1rem;transition:all .16s;}
.stButton>button:hover{border-color:var(--acc);background:rgba(139,124,255,.2);transform:translateY(-1px);color:#fff;}
.stButton>button[kind="primary"]{background:linear-gradient(135deg,#7b6cff,#4aa8ff);border:none;color:#fff;box-shadow:0 6px 18px var(--glow);}
.stButton>button p{font-size:.85rem;}

/* section headers */
.cm-sec{margin:2.1rem 0 .7rem;display:flex;flex-direction:column;gap:2px;}
.cm-sec h3{margin:0;font-size:1.2rem;font-weight:800;letter-spacing:1.4px;color:#fff;}
.cm-sec span{color:var(--mut);font-size:.85rem;}

/* hero */
.cm-hero{position:relative;border-radius:22px;min-height:360px;background-size:cover;background-position:center;
display:flex;align-items:flex-end;overflow:hidden;border:1px solid var(--line);box-shadow:0 24px 70px rgba(0,0,0,.5),0 0 90px var(--glow);}
.cm-hero-body{padding:2.2rem 2.4rem;max-width:640px;display:flex;flex-direction:column;gap:.55rem;}
.cm-eyebrow{font-size:.78rem;font-weight:700;letter-spacing:3px;color:#cfc9ff;}
.cm-hero h1{font-family:'Playfair Display',serif;font-size:2.9rem;line-height:1.05;margin:0;color:#fff;text-shadow:0 4px 24px rgba(0,0,0,.6);}
.cm-meta{color:#d7d9f2;font-size:.92rem;display:flex;gap:.9rem;flex-wrap:wrap;align-items:center;}
.cm-ov{color:#d0d3ee;font-size:.95rem;line-height:1.5;margin:0;}
.cm-hero-poster{flex:0 0 190px;aspect-ratio:2/3;margin:1.6rem 2.2rem 1.6rem auto;border-radius:14px;background-size:cover;background-position:center;box-shadow:0 18px 50px rgba(0,0,0,.6);border:1px solid rgba(255,255,255,.12);}
.cm-hero{justify-content:space-between;}
.cm-whypill{display:inline-block;background:rgba(139,124,255,.22);border:1px solid rgba(139,124,255,.45);border-radius:999px;
padding:.25rem .8rem;font-size:.8rem;color:#e4dfff;width:fit-content;}

/* movie cards */
.cm-card{border-radius:16px;background:var(--card);border:1px solid var(--line);overflow:hidden;
transition:transform .22s ease,box-shadow .22s ease;}
.cm-card:hover{transform:translateY(-6px) scale(1.025);box-shadow:0 18px 40px rgba(0,0,0,.55),0 0 34px var(--glow);}
.cm-art{position:relative;aspect-ratio:2/3;background-size:cover;background-position:center;background-repeat:no-repeat;}
.cm-art::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,rgba(8,10,22,.85));pointer-events:none;}
.cm-badge{position:absolute;top:8px;left:8px;z-index:2;background:rgba(13,16,32,.78);backdrop-filter:blur(6px);
border:1px solid rgba(255,255,255,.14);color:#fff;font-size:.66rem;font-weight:700;padding:.18rem .55rem;border-radius:999px;}
.cm-rate{position:absolute;bottom:8px;left:8px;z-index:2;font-size:.8rem;font-weight:700;color:#ffd666;text-shadow:0 1px 8px #000;}
.cm-meta2{padding:.6rem .7rem .55rem;}
.cm-title{font-weight:700;font-size:.92rem;line-height:1.2;color:#fff;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:2.2em;}
.cm-sub{color:var(--mut);font-size:.74rem;margin-top:.15rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.cm-why{margin-top:.35rem;font-size:.72rem;color:var(--mut);}
.cm-why summary{cursor:pointer;color:#b9b0ff;font-weight:600;list-style:none;}
.cm-why summary::-webkit-details-marker{display:none;}
.cm-why p{margin:.3rem 0 0;line-height:1.35;color:#c8cbe6;}

/* detail panel */
.cm-detail{position:relative;border-radius:22px;overflow:hidden;border:1px solid var(--line);background-size:cover;background-position:center;
box-shadow:0 24px 70px rgba(0,0,0,.5),0 0 80px var(--glow);margin:.5rem 0 1rem;}
.cm-detail-in{display:flex;gap:1.6rem;padding:1.8rem;background:linear-gradient(90deg,rgba(11,14,28,.96) 25%,rgba(11,14,28,.72) 70%,rgba(11,14,28,.45));flex-wrap:wrap;}
.cm-detail-poster{width:190px;aspect-ratio:2/3;border-radius:14px;background-size:cover;background-position:center;flex:0 0 190px;box-shadow:0 14px 40px rgba(0,0,0,.6);}
.cm-detail-txt{flex:1 1 320px;display:flex;flex-direction:column;gap:.55rem;}
.cm-detail-txt h2{font-family:'Playfair Display',serif;font-size:2.2rem;margin:0;color:#fff;}
.cm-chip{display:inline-block;background:rgba(255,255,255,.09);border:1px solid var(--line);border-radius:999px;padding:.15rem .65rem;font-size:.76rem;margin:0 .3rem .3rem 0;color:#dcdff5;}

/* empty / banners */
.cm-banner{border-radius:20px;padding:1.6rem 1.8rem;border:1px solid rgba(139,124,255,.35);margin:1rem 0 .4rem;
background:linear-gradient(135deg,rgba(123,108,255,.22),rgba(74,168,255,.12));}
.cm-banner h2{margin:0 0 .3rem;font-size:1.5rem;color:#fff;}
.cm-banner p{margin:0;color:#cfd2ee;}

/* history strip */
.cm-strip{display:flex;gap:.7rem;overflow-x:auto;padding:.3rem .1rem .8rem;scrollbar-width:thin;}
.cm-mini{flex:0 0 92px;}
.cm-mini .cm-art{border-radius:12px;border:1px solid var(--line);}
.cm-mini div.t{font-size:.68rem;color:var(--mut);margin-top:.25rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}

/* taste bars */
.cm-bar{display:flex;align-items:center;gap:.7rem;margin:.35rem 0;font-size:.88rem;}
.cm-bar .n{width:110px;color:#dcdff5;}
.cm-bar .tr{flex:1;height:12px;background:rgba(255,255,255,.07);border-radius:999px;overflow:hidden;}
.cm-bar .fl{height:100%;border-radius:999px;background:linear-gradient(90deg,#7b6cff,#4aa8ff);}
.cm-bar .v{width:34px;text-align:right;color:var(--mut);}
.cm-stat{background:rgba(255,255,255,.05);border:1px solid var(--line);border-radius:16px;padding:.9rem 1rem;}
.cm-stat b{display:block;font-size:1.5rem;color:#fff;}
.cm-stat span{font-size:.78rem;color:var(--mut);}
.cm-ms{display:inline-flex;align-items:center;gap:.4rem;padding:.35rem .8rem;border-radius:999px;margin:0 .4rem .5rem 0;font-size:.82rem;}
.cm-ms.on{background:rgba(139,124,255,.22);border:1px solid rgba(139,124,255,.5);color:#fff;}
.cm-ms.off{background:rgba(255,255,255,.04);border:1px dashed var(--line);color:#6f7499;filter:grayscale(1);}

/* face-off / double feature */
.cm-vs{display:flex;align-items:center;justify-content:center;height:100%;min-height:80px;font-weight:800;font-size:1.6rem;letter-spacing:3px;
color:#fff;text-shadow:0 0 24px var(--acc);}
.cm-step{font-size:.78rem;font-weight:700;letter-spacing:3px;color:#cfc9ff;margin-bottom:.4rem;}
.cm-pick{border-radius:22px;padding:1.4rem 1.6rem;border:1px solid rgba(139,124,255,.4);background:linear-gradient(135deg,rgba(123,108,255,.2),rgba(20,24,48,.6));}
.cm-pick h2{font-family:'Playfair Display',serif;margin:.2rem 0;font-size:2rem;color:#fff;}

@media (max-width:760px){
 .block-container{padding:.8rem .8rem 3rem;}
 .cm-hero-poster{display:none;}.cm-hero h1{font-size:1.8rem;}.cm-hero-body{padding:1.2rem;}.cm-hero{min-height:300px;}
 .cm-logo{font-size:1.7rem;}.cm-detail-poster{width:120px;flex-basis:120px;}.cm-detail-txt h2{font-size:1.5rem;}
}
</style>
"""

_EXTRA = """
.cm-cmp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:.65rem;}
.cm-cc.both{border-color:rgba(94,234,160,.7);box-shadow:0 0 0 1px rgba(94,234,160,.35),0 0 26px rgba(94,234,160,.22);}
.cm-cc .cm-title{font-size:.8rem;min-height:2.3em;}
.cm-both-tag{position:absolute;top:8px;right:8px;z-index:2;background:rgba(40,160,110,.9);color:#fff;font-size:.62rem;font-weight:800;padding:.15rem .45rem;border-radius:999px;}
.cm-meth{border-radius:18px;padding:1rem 1.2rem;margin-bottom:.8rem;border:1px solid var(--line);}
.cm-meth.cb{background:linear-gradient(135deg,rgba(139,124,255,.22),rgba(30,30,70,.5));border-color:rgba(139,124,255,.5);}
.cm-meth.cf{background:linear-gradient(135deg,rgba(79,195,255,.2),rgba(20,40,70,.5));border-color:rgba(79,195,255,.5);}
.cm-meth h3{margin:0;font-size:1.05rem;letter-spacing:.8px;color:#fff;}
.cm-meth p{margin:.3rem 0 0;font-size:.82rem;color:#cdd1ee;line-height:1.4;}
.cm-flow{font-size:.78rem;color:#b9b0ff;margin-top:.45rem;font-family:ui-monospace,Menlo,monospace;}
.cm-venn{position:relative;width:340px;max-width:100%;height:210px;margin:.4rem auto 0;}
.cm-venn .c{position:absolute;top:5px;width:200px;height:200px;border-radius:50%;}
.cm-venn .ca{left:0;background:rgba(139,124,255,.38);border:2px solid rgba(139,124,255,.9);}
.cm-venn .cb2{left:138px;background:rgba(79,195,255,.34);border:2px solid rgba(79,195,255,.9);}
.cm-venn .n{position:absolute;top:70px;text-align:center;color:#fff;line-height:1.1;width:90px;}
.cm-venn .n b{display:block;font-size:2rem;}.cm-venn .n span{font-size:.68rem;color:#e0e3fa;}
.cm-venn .n1{left:18px;}.cm-venn .n2{left:125px;}.cm-venn .n3{left:232px;}
.cm-vlab{display:flex;justify-content:space-between;width:340px;max-width:100%;margin:.2rem auto 1rem;font-size:.74rem;color:var(--mut);}
.cm-cbar{margin:.55rem 0 .9rem;}
.cm-cbar .t{font-size:.84rem;color:#fff;font-weight:600;margin-bottom:.25rem;}
.cm-cbar .t small{color:var(--mut);font-weight:400;}
.cm-cbar .r{display:flex;align-items:center;gap:.6rem;margin:.18rem 0;font-size:.76rem;color:#cfd2ee;}
.cm-cbar .r i{width:34px;font-style:normal;color:var(--mut);}
.cm-cbar .tr{flex:1;height:11px;background:rgba(255,255,255,.07);border-radius:999px;overflow:hidden;}
.cm-cbar .f1{height:100%;background:linear-gradient(90deg,#7b6cff,#a99dff);border-radius:999px;}
.cm-cbar .f2{height:100%;background:linear-gradient(90deg,#3aa7ff,#7fd4ff);border-radius:999px;}
.cm-cbar .v{width:62px;text-align:right;font-variant-numeric:tabular-nums;}
.cm-note{border-left:3px solid var(--acc);background:rgba(255,255,255,.04);padding:.7rem 1rem;border-radius:0 12px 12px 0;font-size:.86rem;color:#d3d6f0;margin:.6rem 0;}
"""
CSS = CSS.replace("</style>", _EXTRA + "</style>")

_FIX = """
div[data-testid="stRadio"] label[data-baseweb="radio"]>div:first-child,div[data-testid="stRadio"] label>div:first-child{display:none!important;}
div[data-testid="stRadio"] label[data-baseweb="radio"]{padding-left:.95rem!important;}
.cm-card{max-width:280px;}
div[data-testid="stColumn"] div[data-testid="stHorizontalBlock"],div[data-testid="column"] div[data-testid="stHorizontalBlock"]{max-width:280px;}
.cm-cmp-grid .cm-card{max-width:none;}
"""
CSS = CSS.replace("</style>", _FIX + "</style>")

_AUTH = """
.cm-collage{display:flex;gap:.6rem;overflow:hidden;margin:-.4rem -2rem 0;padding:0 1rem;height:210px;mask-image:linear-gradient(180deg,#000 30%,transparent);-webkit-mask-image:linear-gradient(180deg,#000 30%,transparent);}
.cm-tile{flex:0 0 140px;transform:rotate(-3deg);opacity:.85;}
.cm-tile .cm-art{border-radius:12px;box-shadow:0 12px 30px rgba(0,0,0,.55);}
.cm-auth{text-align:center;margin:-2.4rem 0 1.2rem;}
.cm-or{text-align:center;color:var(--mut);font-size:.8rem;margin:.6rem 0;letter-spacing:2px;}
.cm-userchip{font-size:.78rem;color:#cfc9ff;text-align:right;margin-bottom:.25rem;}
"""
CSS = CSS.replace("</style>", _AUTH + "</style>")

_FOOT = """
.cm-footer{margin:3.5rem 0 0;padding:1.4rem 0 .5rem;border-top:1px solid var(--line);text-align:center;color:var(--mut);font-size:.8rem;line-height:1.7;}
.cm-footer b{color:#fff;letter-spacing:.5px;}.cm-footer span{font-size:.72rem;opacity:.7;}
"""
CSS = CSS.replace("</style>", _FOOT + "</style>")

# Remove blank lines: a blank line can terminate a raw-HTML block in some markdown parsers.
CSS = "\n".join(line for line in CSS.splitlines() if line.strip())
