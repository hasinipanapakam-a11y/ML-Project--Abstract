"""Direct comparison of the two recommendation pipelines.

    Content-Based:   movie metadata -> TF-IDF -> cosine similarity            (src/content_based.py)
    Collaborative:   user-movie ratings -> SVD factors -> latent scores        (src/collaborative.py)

Nothing here blends the two. Each function below calls ONE pipeline; `compare_lists` and
`evaluate_offline` then analyse the two outputs side by side.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .collaborative import fold_in_scores, get_svd_recommendations, holdout_split, predict_user_ratings
from .content_based import get_content_recommendations


# ───────────────────────────────────────────────────────────── rating index
def _group(keys: np.ndarray, a: np.ndarray, b: np.ndarray) -> dict:
    order = np.argsort(keys, kind="stable")
    k, a, b = keys[order], a[order], b[order]
    uniq, start = np.unique(k, return_index=True)
    return {int(u): (x, y) for u, x, y in zip(uniq, np.split(a, start[1:]), np.split(b, start[1:]))}


def build_rating_index(ratings: pd.DataFrame) -> dict:
    u, m, r = (ratings[c].to_numpy() for c in ("userId", "movieId", "rating"))
    return {"by_user": _group(u, m, r), "by_movie": _group(m, u, r)}


def co_rating_stats(index: dict, a: int, b: int) -> dict:
    """Evidence straight from the ratings: who rated both movies and how they rated them."""
    ua, ra = index["by_movie"].get(int(a), (np.array([]), np.array([])))
    ub, rb = index["by_movie"].get(int(b), (np.array([]), np.array([])))
    _, ia, ib = np.intersect1d(ua, ub, return_indices=True)
    n = len(ia)
    liked_a = int((ra >= 4).sum())
    both = int(((ra[ia] >= 4) & (rb[ib] >= 4)).sum()) if n else 0
    fans_a_who_rated_b = int((ra[ia] >= 4).sum()) if n else 0
    return {"n_both": n, "liked_both": both, "fans_of_a_rated_b": fans_a_who_rated_b, "liked_a": liked_a}


# ───────────────────────────────────────────── pipeline 1 — content-based
def content_recs_for_movie(model: dict, movies: pd.DataFrame, movie_id: int, n: int = 10) -> list[dict]:
    row = movies.loc[movies["movieId"] == int(movie_id)]
    if row.empty:
        return []
    df = get_content_recommendations(model, movies, row["title"].iloc[0], n)
    return [{"movieId": int(r.movieId), "score": float(r.similarity), "rank": k + 1}
            for k, r in enumerate(df.itertuples())]


def content_recs_for_user(model: dict, movies: pd.DataFrame, id_index: dict, user_movies: np.ndarray,
                          user_ratings: np.ndarray, n: int = 10, min_ratings: int = 15) -> tuple[list[dict], list[int]]:
    """Profile = the user's own liked movies; score = mean cosine similarity to them. No other users involved."""
    liked = user_movies[user_ratings >= 4]
    if len(liked) == 0:
        liked = user_movies[np.argsort(-user_ratings)[:5]]
    order = np.argsort(-user_ratings[np.isin(user_movies, liked)])
    seeds = liked[order][:10]
    idx = [id_index[int(m)] for m in seeds if int(m) in id_index]
    if not idx:
        return [], []
    score = model["sim"][idx].mean(axis=0).astype(float)
    mask = np.isin(movies["movieId"].to_numpy(), user_movies) | (movies["n_ratings"].to_numpy() < min_ratings)
    score[mask] = -9
    top = np.argsort(-score)[:n]
    return ([{"movieId": int(movies["movieId"].iloc[i]), "score": float(score[i]), "rank": k + 1}
             for k, i in enumerate(top)], [int(m) for m in seeds])


# ───────────────────────────────────────────── pipeline 2 — collaborative
def cf_recs_for_movie(svd: dict, movies: pd.DataFrame, movie_id: int, n: int = 10) -> list[dict]:
    """Movies closest to the selected movie in the SVD latent space learned from user ratings."""
    df = get_svd_recommendations(svd, movies, seed_movie_ids=[movie_id], n=n, exclude_ids=[movie_id])
    out = []
    for k, r in enumerate(df.itertuples()):
        j = svd["id_index"][int(r.movieId)]
        out.append({"movieId": int(r.movieId), "score": float(r.svd_score), "rank": k + 1,
                    "latent_cos": float(svd["Qn"][j] @ svd["Qn"][svd["id_index"][int(movie_id)]]),
                    "typical_pred": float(np.clip(svd["mu"] + svd["bi"][j], 0.5, 5.0))})
    return out


def cf_recs_for_user(svd: dict, movies: pd.DataFrame, user_id: int, user_movies: np.ndarray,
                     n: int = 10, min_ratings: int = 15) -> list[dict]:
    """Top predicted ratings for a real MovieLens user: mu + bu + bi + p_u . q_i."""
    pred = predict_user_ratings(svd, user_id)
    if pred is None:
        return []
    score = pred.astype(float).copy()
    mask = np.isin(movies["movieId"].to_numpy(), user_movies) | (movies["n_ratings"].to_numpy() < min_ratings)
    score[mask] = -9
    top = np.argsort(-score)[:n]
    return [{"movieId": int(movies["movieId"].iloc[i]), "score": float(score[i]), "rank": k + 1,
             "pred": float(score[i])} for k, i in enumerate(top)]


# ───────────────────────────────────────────────────── comparing outputs
def compare_lists(cb: list[dict], cf: list[dict], movies: pd.DataFrame, ref_genres: set[str]) -> dict:
    """Overlap, ranking differences and per-list profile metrics for two recommendation lists."""
    ids_cb, ids_cf = [r["movieId"] for r in cb], [r["movieId"] for r in cf]
    s_cb, s_cf = set(ids_cb), set(ids_cf)
    both, only_cb, only_cf = s_cb & s_cf, s_cb - s_cf, s_cf - s_cb
    union = s_cb | s_cf
    rk_cb = {r["movieId"]: r["rank"] for r in cb}
    rk_cf = {r["movieId"]: r["rank"] for r in cf}
    sc_cb = {r["movieId"]: r["score"] for r in cb}
    sc_cf = {r["movieId"]: r["score"] for r in cf}
    mv = movies.set_index("movieId")
    rows = []
    for m in sorted(union, key=lambda x: min(rk_cb.get(x, 99), rk_cf.get(x, 99))):
        a, b = rk_cb.get(m), rk_cf.get(m)
        rows.append({"Movie": f"{mv.at[m, 'name']} ({int(mv.at[m, 'year']) if mv.at[m, 'year'] == mv.at[m, 'year'] else '—'})",
                     "Content rank": a, "Collab. rank": b,
                     "Rank shift (CF − CB)": (b - a) if a and b else None,
                     "Found by": "Both" if m in both else ("Content only" if m in s_cb else "Collaborative only"),
                     "Content score": sc_cb.get(m), "Collab. score": sc_cf.get(m)})
    rho = None
    if len(both) >= 3:
        ab = pd.DataFrame({"a": [rk_cb[m] for m in both], "b": [rk_cf[m] for m in both]})
        rho = float(ab["a"].corr(ab["b"], method="spearman"))

    def profile(ids: list[int]) -> dict:
        if not ids:
            return {}
        sub = mv.loc[ids]
        gl = sub["genre_list"].tolist()
        jac = [len(set(g) & ref_genres) / max(len(set(g) | ref_genres), 1) for g in gl]
        return {"genre_overlap": float(np.mean(jac)),
                "cross_genre": float(np.mean([len(set(g) & ref_genres) == 0 for g in gl])),
                "median_ratings": float(sub["n_ratings"].median()),
                "mean_avg_rating": float(sub["avg_rating"].mean()),
                "genres_covered": len({x for g in gl for x in g})}
    return {"both": sorted(both, key=lambda m: rk_cb[m]), "only_cb": [m for m in ids_cb if m in only_cb],
            "only_cf": [m for m in ids_cf if m in only_cf],
            "jaccard": len(both) / len(union) if union else 0.0, "n": max(len(cb), len(cf)),
            "spearman": rho, "table": pd.DataFrame(rows), "cb_profile": profile(ids_cb), "cf_profile": profile(ids_cf)}


# ───────────────────────────────────────────────────── offline evaluation
def evaluate_offline(E, ratings: pd.DataFrame, svd: dict, K: int = 10, max_users: int = 3000,
                     knn: int = 20, seed: int = 0, min_support: int = 30) -> dict:
    """Leak-free comparison on the SAME per-user hold-out the SVD RMSE uses.

    A) Rating prediction RMSE on held-out ratings
         item-mean baseline | content-based kNN | SVD
       (content kNN: item mean + similarity-weighted residuals of the user's own training ratings)
    B) Top-K retrieval: hide one movie a user liked (>=4) from the TEST split; build the profile from the user's
       liked TRAIN movies; see whether each method puts the hidden movie in its top-K.
       The collaborative side uses the SVD factors trained on the training split only.
    """
    rng = np.random.default_rng(seed)
    train, test = holdout_split(ratings, 42)
    gm = float(train["rating"].mean())
    n_i = train.groupby("movieId").size().reindex(E.ids).fillna(0).to_numpy()
    s_i = train.groupby("movieId")["rating"].sum().reindex(E.ids).fillna(0).to_numpy()
    item_mean = (s_i + 15 * gm) / (n_i + 15)
    tr_user = {u: (np.array([E.idx[int(m)] for m in ms]), rs) for u, (ms, rs) in
               build_rating_index(train)["by_user"].items()}

    # A) rating prediction ------------------------------------------------------------------
    p_cb, p_item, y, personalised = [], [], [], 0
    for u, m, r in zip(test["userId"].to_numpy(), test["movieId"].to_numpy(), test["rating"].to_numpy()):
        i = E.idx[int(m)]
        base = p = item_mean[i]
        rec = tr_user.get(int(u))
        if rec is not None:
            idxs, rs = rec
            w = E.sim[i, idxs].astype(float)
            if len(idxs) > knn:
                top = np.argpartition(-w, knn)[:knn]
                idxs, rs, w = idxs[top], rs[top], w[top]
            w = np.maximum(w, 0)
            if w.sum() > 0:
                p = base + float((w * (rs - item_mean[idxs])).sum() / (w.sum() + 1.0))
                personalised += 1
        p_cb.append(min(5.0, max(0.5, p))); p_item.append(base); y.append(r)
    y = np.array(y)
    rmse = lambda p: float(np.sqrt(np.mean((np.array(p) - y) ** 2)))
    ratings_eval = {"n_test": len(y), "personalised_share": personalised / len(y),
                    "item_mean_rmse": rmse(p_item), "content_rmse": rmse(p_cb),
                    "svd_rmse": float(svd["rmse"]), "svd_bias_rmse": float(svd["rmse_baseline"]),
                    "svd_backend": svd["backend"]}

    # B) top-K retrieval --------------------------------------------------------------------
    # Candidates: movies with >= min_support TRAIN ratings (same filter for every method; very rarely
    # rated movies make predicted ratings unreliable). Held-out movies outside that set are skipped.
    Qn, shrink = svd["eval_Qn"], svd["eval_shrink"]
    te_liked = _group(test.loc[test["rating"] >= 4, "userId"].to_numpy(),
                      test.loc[test["rating"] >= 4, "movieId"].to_numpy(),
                      test.loc[test["rating"] >= 4, "rating"].to_numpy())
    users = [u for u in te_liked if u in tr_user and (tr_user[u][1] >= 4).sum() >= 2]
    if len(users) > max_users:
        users = list(rng.choice(users, max_users, replace=False))
    names = ("content", "collab_pred", "collab_latent", "popular")
    res = {k: {"hit": [], "pct_rank": [], "cover": set(), "pop": []} for k in names}
    over_cp, over_cl = [], []
    for u in users:
        idxs, rs = tr_user[u]
        held = E.idx[int(rng.choice(te_liked[u][0]))]
        excl = np.zeros(E.n, bool); excl[idxs] = True
        excl |= n_i < min_support
        if excl[held]:
            continue
        seeds = idxs[rs >= 4]
        v = Qn[seeds].mean(axis=0); v = v / max(np.linalg.norm(v), 1e-9)
        scores = {"content": E.sim[seeds].mean(axis=0),
                  "collab_pred": fold_in_scores(svd["eval_Q"], svd["eval_bi"], svd["eval_mu"], idxs, rs),
                  "collab_latent": (Qn @ v) * shrink, "popular": n_i.astype(float)}
        tops = {}
        for k, sc in scores.items():
            sc = np.where(excl, -np.inf, sc)
            top = np.argpartition(-sc, K)[:K]; top = top[np.argsort(-sc[top])]
            tops[k] = set(top.tolist())
            res[k]["hit"].append(held in tops[k])
            res[k]["pct_rank"].append(float((sc > sc[held]).sum() / max((~excl).sum(), 1)))
            res[k]["cover"] |= tops[k]
            res[k]["pop"].append(float(np.median(n_i[top])))
        jac = lambda a, b: len(a & b) / len(a | b)
        over_cp.append(jac(tops["content"], tops["collab_pred"])); over_cl.append(jac(tops["content"], tops["collab_latent"]))
    n_u = len(res["content"]["hit"])
    topk = {}
    for k, d in res.items():
        p = float(np.mean(d["hit"])) if n_u else 0.0
        topk[k] = {"hit_rate": p, "se": float(np.sqrt(p * (1 - p) / max(n_u, 1))),
                   "mean_pct_rank": float(np.mean(d["pct_rank"])) if n_u else 1.0,
                   "coverage": len(d["cover"]) / E.n, "median_popularity": float(np.mean(d["pop"])) if n_u else 0.0}
    return {"ratings": ratings_eval, "topk": topk, "K": K, "n_users": n_u, "min_support": min_support,
            "overlap_content_vs_pred": float(np.mean(over_cp)) if over_cp else 0.0,
            "overlap_content_vs_latent": float(np.mean(over_cl)) if over_cl else 0.0}
