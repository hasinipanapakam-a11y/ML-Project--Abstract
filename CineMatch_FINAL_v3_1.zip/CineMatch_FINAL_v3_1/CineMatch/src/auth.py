"""Local accounts for CineMatch: sign up / log in, with per-user saved state.

SQLite (standard library) in data/cinematch_users.db. Passwords are never stored: only a random
per-user salt and a PBKDF2-HMAC-SHA256 hash (200k iterations). This is a prototype-grade local login,
not a hosted identity provider (no email verification / password reset).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import sqlite3
import time
from pathlib import Path

DB_PATH = Path(os.environ.get("CINEMATCH_DB", Path(__file__).resolve().parents[1] / "data" / "cinematch_users.db"))
_USER_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
ITER = 200_000
PERSIST_KEYS = ("watch_history", "watchlist", "faceoff_preferences", "onboarding_genres", "moods_tried",
                "watched_ever", "saved_ever", "genres_seen", "surprise_history", "selected_mood", "discovery")


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.execute("CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY COLLATE NOCASE, salt BLOB, hash BLOB, created REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS state(username TEXT PRIMARY KEY COLLATE NOCASE, data TEXT, updated REAL)")
    return c


def _hash(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITER)


def create_user(username: str, password: str, confirm: str | None = None) -> tuple[bool, str]:
    username = (username or "").strip()
    if not _USER_RE.match(username):
        return False, "Username must be 3–20 characters: letters, numbers or underscore."
    if len(password or "") < 6:
        return False, "Password must be at least 6 characters."
    if confirm is not None and password != confirm:
        return False, "Passwords don't match."
    salt = os.urandom(16)
    try:
        with _conn() as c:
            c.execute("INSERT INTO users VALUES (?,?,?,?)", (username, salt, _hash(password, salt), time.time()))
    except sqlite3.IntegrityError:
        return False, "That username is taken — try another or log in."
    return True, f"Welcome to CineMatch, {username}! 🎬"


def verify_user(username: str, password: str) -> tuple[bool, str]:
    username = (username or "").strip()
    with _conn() as c:
        row = c.execute("SELECT username, salt, hash FROM users WHERE username=?", (username,)).fetchone()
    if not row or not hmac.compare_digest(_hash(password or "", row[1]), row[2]):
        return False, "Wrong username or password."
    return True, row[0]  # canonical capitalisation


def load_state(username: str) -> dict:
    with _conn() as c:
        row = c.execute("SELECT data FROM state WHERE username=?", (username,)).fetchone()
    try:
        data = json.loads(row[0]) if row else {}
    except ValueError:
        data = {}
    return {k: data[k] for k in PERSIST_KEYS if data.get(k) is not None}


def save_state(username: str, state: dict) -> str:
    """Persist the whitelisted keys; returns the JSON string (callers use it to skip redundant writes)."""
    blob = json.dumps({k: state.get(k) for k in PERSIST_KEYS}, sort_keys=True)
    with _conn() as c:
        c.execute("INSERT INTO state VALUES (?,?,?) ON CONFLICT(username) DO UPDATE SET data=excluded.data, updated=excluded.updated",
                  (username, blob, time.time()))
    return blob
