"""Hybrid recommender: content similarity + SVD latent similarity + genre profile + quality.

Every public method returns a list of recs: {"movieId", "why", "badge"} where `why`
is built from the signals that actually produced the pick.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .personalization import BADGES, MOODS, NIGHT_COMPANY, NIGHT_LEVEL, NIGHT_MOOD

SEARCH_SYNONYMS = {
    "funny": "Comedy", "comedy": "Comedy", "laugh": "Comedy", "comedies": "Comedy", "scary": "Horror",
    "horror": "Horror", "spooky": "Horror", "kids": "Children", "children": "Children", "family": "Children",
    "cartoon": "Animation", "cartoons": "Animation", "animated": "Animation", "animation": "Animation",
    "romantic": "Romance", "romance": "Romance", "love": "Romance", "scifi": "Sci-Fi", "sci-fi": "Sci-Fi",
    "sci fi": "Sci-Fi", "space": "Sci-Fi", "action": "Action", "war": "War", "western": "Western",
    "documentary": "Documentary", "musical": "Musical", "crime": "Crime", "mystery": "Mystery",
    "thriller": "Thriller", "suspense": "Thriller", "drama": "Drama", "fantasy": "Fantasy",
    "adventure": "Adventure", "noir": "Film-Noir", "film-noir": "Film-Noir",
}


def _stem(name: str) -> str:
    s = re.split(r"[:\-–]| part | episode ", name.lower())[0].strip()
    s = re.sub(r"\s+(\d+|[ivx]+)$", "", s)
    return s


class Engine:
    def __init__(self, movies: pd.DataFrame, content: dict, svd: dict):
        self.m = movies.reset_index(drop=True)
        n = self.n = len(self.m)
        self.ids = self.m["movieId"].to_numpy()
        self.idx = {int(i): k for k, i in enumerate(self.ids)}
        self.sim = content["sim"]
        self.svd = svd
        self.Qn, self.shrink = svd["Qn"], svd["shrink"]
        self.genres = sorted({g for gl in self.m["genre_list"] for g in gl})
        gi = {g: k for k, g in enumerate(self.genres)}
        self.gi = gi
        self.G = np.zeros((n, len(self.genres)), np.float32)
        for k, gl in enumerate(self.m["genre_list"]):
            for g in gl:
                self.G[k, gi[g]] = 1.0
        self.n_rat = self.m["n_ratings"].to_numpy()
        self.q = np.clip((self.m["bayes"].to_numpy() - 2.8) / 1.6, 0, 1).astype(np.float32)
        self.pop = (np.log1p(self.n_rat) / np.log1p(self.n_rat.max())).astype(np.float32)
        self.stems = [_stem(x) for x in self.m["name"]]
        self.p75 = float(np.percentile(self.n_rat, 75))

    # ------------------------------------------------------------------ helpers
    def info(self, i: int) -> dict:
        r = self.m.iloc[i]
        return {"movieId": int(r.movieId), "name": r["name"], "title": r["title"],
                "year": None if np.isnan(r.year) else int(r.year), "genres": list(r.genre_list),
                "avg": None if np.isnan(r.avg_rating) else float(r.avg_rating), "n": int(r.n_ratings),
                "tmdbId": None if np.isnan(r.tmdbId) else int(r.tmdbId)}

    def info_by_id(self, mid: int) -> dict | None:
        i = self.idx.get(int(mid))
        return None if i is None else self.info(i)

    def seeds_from(self, ctx: dict, use=("history", "list", "faceoff")) -> dict[int, float]:
        """Weighted seed movies: watch history (recent first) > list = face-off picks."""
        w: dict[int, float] = {}
        for name, base in (("history", 1.0), ("list", 0.5), ("faceoff", 0.5)):
            if name not in use:
                continue
            for pos, mid in enumerate(ctx.get(name, [])):
                i = self.idx.get(int(mid))
                if i is not None:
                    w[i] = max(w.get(i, 0.0), base * (1 - 0.02 * min(pos, 20)))
        return w

    def excluded(self, ctx: dict, lists: bool = True, extra_ids=()) -> np.ndarray:
        ids = set(map(int, ctx.get("history", []))) | set(map(int, extra_ids))
        if lists:
            ids |= set(map(int, ctx.get("list", [])))
        return np.isin(self.ids, list(ids)) if ids else np.zeros(self.n, bool)

    def _affinity(self, seeds: dict[int, float], onboard: list[str]) -> np.ndarray | None:
        if seeds:
            idxs = np.fromiter(seeds.keys(), int)
            ws = np.array([seeds[i] for i in idxs], np.float32)
            A = (ws[:, None] * self.G[idxs]).sum(0)
        elif onboard:
            A = np.zeros(len(self.genres), np.float32)
            for g in onboard:
                if g in self.gi:
                    A[self.gi[g]] = 1.0
        else:
            return None
        return A / A.sum() if A.sum() > 0 else None

    def _signals(self, seeds, onboard):
        z = np.zeros(self.n, np.float32)
        sig = {"c": z, "s": z, "g": z, "A": None, "seeds": np.array([], int), "onboard": onboard}
        A = self._affinity(seeds, onboard)
        if A is not None:
            sig["A"] = A
            sig["g"] = np.clip((self.G @ A) / max(A.max(), 1e-9), 0, 1)
        if seeds:
            idxs = np.fromiter(seeds.keys(), int)
            ws = np.array([seeds[i] for i in idxs], np.float32)
            c = (ws[:, None] * self.sim[idxs]).sum(0) / ws.sum()
            cm = c.copy(); cm[idxs] = 0
            sig["c"] = c / max(float(cm.max()), 1e-6)
            sig["c_raw"] = c
            v = (ws[:, None] * self.Qn[idxs]).sum(0)
            v /= max(np.linalg.norm(v), 1e-9)
            s = (self.Qn @ v) * self.shrink
            s[idxs] = s.min()
            sig["s"] = (s - s.min()) / max(float(s.max() - s.min()), 1e-9)
            sig["seeds"] = idxs
        return sig

    # --------------------------------------------------------------- explanations
    def _explain(self, i: int, sig: dict) -> str:
        seeds = sig["seeds"]
        gl = self.m.at[i, "genre_list"]
        if len(seeds):
            sims = self.sim[i, seeds]; j = int(np.argmax(sims)); sj = int(seeds[j])
            shared = [g for g in gl if g in self.m.at[sj, "genre_list"]]
            if sims[j] >= 0.5:
                tail = f" (shared: {', '.join(shared[:3])})" if shared else ""
                return f"Similar to {self.m.at[sj, 'name']}{tail}."
            ssim = (self.Qn[i] @ self.Qn[seeds].T) * self.shrink[i]
            k = int(np.argmax(ssim))
            if ssim[k] >= 0.45:
                return (f"Collaborative filtering: rated alike to {self.m.at[int(seeds[k]), 'name']} "
                        "by the same users (SVD).")
            A = sig["A"]
            if A is not None:
                top = [self.genres[k] for k in np.argsort(-A)[:2] if A[k] > 0 and self.genres[k] in gl]
                if top:
                    return f"Matches your frequent {' + '.join(top)} preference."
            if sims[j] >= 0.3:
                return f"Content-similar to {self.m.at[sj, 'name']} in your history."
        elif sig["onboard"]:
            hit = [g for g in sig["onboard"] if g in gl]
            if hit:
                return f"Matches the genres you picked: {', '.join(hit)}."
        return f"Well rated by the community ({self.m.at[i, 'avg_rating']:.1f}★ from {self.n_rat[i]} ratings)."

    # --------------------------------------------------------------------- ranking
    def rank(self, ctx: dict, n: int = 10, mode: str = "familiar", use=("history", "list", "faceoff"),
             seeds: dict | None = None, exclude: np.ndarray | None = None, extra: np.ndarray | None = None,
             extra_w: float = 0.0, gate: np.ndarray | None = None, w: dict | None = None,
             min_ratings: int = 8, rng_seed: int = 0, badge: str = "similar", context=None,
             cap_stem: int = 2) -> list[dict]:
        seeds = self.seeds_from(ctx, use) if seeds is None else seeds
        onboard = [] if seeds else list(ctx.get("onboarding", []))
        sig = self._signals(seeds, onboard)
        excl = self.excluded(ctx) if exclude is None else exclude
        rng = np.random.default_rng(rng_seed)

        if seeds:
            wt = {"familiar": dict(c=.40, s=.20, g=.15, q=.20, p=.05),
                  "explore": dict(c=.30, s=.25, g=.15, q=.20, p=.10),
                  "wild": dict(c=.0, s=.20, g=.0, q=.35, p=.10)}[mode]
        elif onboard:
            wt = dict(c=0, s=0, g=.4, q=.4, p=.2)
        else:
            wt = dict(c=0, s=0, g=0, q=.6, p=.4)
        if w:
            wt = {**wt, **w}
        score = wt["c"] * sig["c"] + wt["s"] * sig["s"] + wt["g"] * sig["g"] + wt["q"] * self.q + wt["p"] * self.pop
        if mode == "wild" and seeds:
            score = score + .25 * (1 - sig["g"]) + .10 * rng.random(self.n)
        if extra is not None:
            score = score + extra_w * extra

        valid = ~excl & (self.n_rat >= min_ratings)
        if mode == "wild":
            valid &= self.q >= 0.35
        if gate is not None:
            valid &= gate
        if not valid.any():
            return []
        score = np.where(valid, score, -np.inf)
        pool = np.argsort(-score)[: max(n * 8, 60)]
        pool = pool[np.isfinite(score[pool])]
        lo, hi = score[pool].min(), score[pool].max()
        norm = (score[pool] - lo) / max(hi - lo, 1e-9)

        chosen: list[int] = []
        stem_count: dict[str, int] = {}
        lam = {"familiar": 0.8, "explore": 0.6, "wild": 1.0}[mode]
        order = list(range(len(pool)))
        if mode == "wild":  # sample from the good-and-different pool instead of a strict top-n
            top = order[: min(len(order), 60)]
            p = np.maximum(norm[top], 0.05); p = p / p.sum()
            order = list(rng.choice(top, size=len(top), replace=False, p=p))
        while len(chosen) < n and order:
            if mode == "wild":
                k = order.pop(0)
            else:
                if chosen:
                    ms = self.sim[np.ix_(pool[order], chosen)].max(axis=1)
                else:
                    ms = np.zeros(len(order))
                k = order.pop(int(np.argmax(lam * norm[order] - (1 - lam) * ms)))
            i = int(pool[k])
            st = self.stems[i]
            if stem_count.get(st, 0) >= cap_stem:
                continue
            stem_count[st] = stem_count.get(st, 0) + 1
            chosen.append(i)
        out = []
        for i in chosen:
            if context is not None:
                why = context(i, sig)
            elif mode == "wild" and seeds and sig["g"][i] < 0.35:
                why = "Outside your usual genres — a well-rated pick for variety."
            else:
                why = self._explain(i, sig)
            out.append({"movieId": int(self.ids[i]), "why": why, "badge": BADGES[badge]})
        return out

    # --------------------------------------------------------------- feature logic
    def popular(self, ctx, n=12):
        return self.rank(ctx, n, use=(), w=dict(q=.5, p=.5), badge="trend",
                         context=lambda i, s: f"Widely rated ({self.n_rat[i]} ratings, {self.m.at[i, 'avg_rating']:.1f}★).")

    def because_you_watched(self, ctx, anchor_mid, n=6):
        a = self.idx.get(int(anchor_mid))
        if a is None:
            return []
        name = self.m.at[a, "name"]

        def why(i, sig):
            shared = [g for g in self.m.at[i, "genre_list"] if g in self.m.at[a, "genre_list"]]
            return f"Similar to {name}" + (f" (shared: {', '.join(shared[:3])})." if shared else ".")
        return self.rank(ctx, n, seeds={a: 1.0}, w=dict(c=.6, s=.15, g=.05, q=.15, p=.05), context=why)

    def made_for_history(self, ctx, n=12, mode="familiar", rng_seed=0):
        if not ctx.get("history"):
            return []
        b = {"familiar": "similar", "explore": "explore", "wild": "wild"}[mode]
        return self.rank(ctx, n, mode=mode, use=("history",), badge=b, rng_seed=rng_seed)

    def genre_row(self, ctx, genre, n=12):
        gate = self.G[:, self.gi[genre]] > 0 if genre in self.gi else None
        return self.rank(ctx, n, use=("history",), gate=gate, badge="similar",
                         context=lambda i, s: f"{genre} movie that fits your history. " + self._explain(i, s))

    def _mood_vec(self, genres: dict, avoid: list):
        wv = np.zeros(len(self.genres), np.float32)
        for g, x in genres.items():
            if g in self.gi:
                wv[self.gi[g]] = x
        av = np.zeros(len(self.genres), np.float32)
        for g in avoid:
            if g in self.gi:
                av[self.gi[g]] = 1
        m = np.clip((self.G @ wv) / max(wv.max(), 1e-9), 0, 1)
        m = np.where((self.G @ av) > 0, m * 0.4, m)
        return m, wv

    def mood_picks(self, ctx, mood_key, n=12, mode="familiar", companions: dict | None = None, rng_seed=0):
        mood = MOODS[mood_key]
        gen, avoid = dict(mood["genres"]), list(mood["avoid"])
        if companions:
            for g, x in companions["genres"].items():
                gen[g] = max(gen.get(g, 0), x * 0.8)
            avoid += companions["avoid"]
        m, wv = self._mood_vec(gen, avoid)
        if mood.get("niche"):  # "Something Different": lean away from mega-popular titles
            m = m * (1 - 0.5 * self.pop)

        def why(i, sig):
            hit = [g for g in self.m.at[i, "genre_list"] if g in gen][:3]
            t = f"Mood match: {mood['label']} → {', '.join(hit)}."
            if len(sig["seeds"]) and sig["c"][i] >= 0.6:
                t += " Also close to your watch history."
            return t
        return self.rank(ctx, n, mode=mode, extra=m, extra_w=.7, gate=m >= 0.45, badge="mood",
                         context=why, rng_seed=rng_seed, w=dict(q=.25, p=.05 if not mood.get("niche") else 0))

    def trending(self, ctx, n=12):
        if not self.seeds_from(ctx):
            return self.popular(ctx, n)
        return self.rank(ctx, n, w=dict(c=.20, s=0, g=.25, q=.25, p=.30), badge="trend",
                         context=lambda i, s: (f"Popular ({self.n_rat[i]} ratings) and well rated, in genres you watch."
                                               if s["g"][i] > .4 else f"Popular and well rated; {self._explain(i, s)}"))

    def hidden_gems(self, ctx, n=12):
        gate = (self.n_rat >= 10) & (self.n_rat <= self.p75) & (self.m["bayes"].to_numpy() >= 3.7)
        ev = np.minimum(self.n_rat / 50.0, 1.0).astype(np.float32)
        seeds = self.seeds_from(ctx)
        def why(i, s):
            base = f"Rated {self.m.at[i, 'avg_rating']:.1f}★ by {self.n_rat[i]} people — a less mainstream pick."
            return base + (" " + self._explain(i, s) if len(s["seeds"]) else "")
        return self.rank(ctx, n, gate=gate, extra=ev, extra_w=.1, w=dict(c=.25, s=.10, g=.20, q=.35, p=0),
                         badge="gem", context=why, min_ratings=10, cap_stem=1)

    def surprise(self, ctx, seen_ids, rng_seed):
        ex = self.excluded(ctx, lists=False, extra_ids=seen_ids)
        pool = self.rank(ctx, 30, mode="explore", exclude=ex, min_ratings=15, rng_seed=rng_seed, badge="pick",
                         w=dict(q=.3))
        pool = [r for r in pool if self.m.at[self.idx[r["movieId"]], "bayes"] >= 3.5] or pool
        if not pool:
            return None
        r = pool[int(np.random.default_rng(rng_seed).integers(len(pool)))]
        i = self.idx[r["movieId"]]
        seeds = self.seeds_from(ctx, ("history",))
        if seeds:
            sig = self._signals(seeds, [])
            top = [self.genres[k] for k in np.argsort(-sig["A"])[:3] if sig["A"][k] > 0 and self.genres[k] in self.m.at[i, "genre_list"]]
            if top:
                r["why"] = f"Matches your interest in {' and '.join(top[:2])}."
        return r

    def faceoff(self, ctx, rng_seed):
        rng = np.random.default_rng(rng_seed)
        recs = self.rank(ctx, 25, mode="explore", rng_seed=rng_seed, min_ratings=20) or []
        if len(recs) < 2:
            return None
        a = recs[int(rng.integers(len(recs)))]
        ga = set(self.m.at[self.idx[a["movieId"]], "genre_list"])
        pool = self.rank(ctx, 40, mode="wild", min_ratings=20, rng_seed=rng_seed + 1) or recs
        pool = [r for r in pool if r["movieId"] != a["movieId"]]
        pool.sort(key=lambda r: len(ga & set(self.m.at[self.idx[r["movieId"]], "genre_list"])))
        return [a["movieId"], pool[0]["movieId"]]

    def more_like(self, ctx, mid, n=6, why_prefix="Similar to"):
        a = self.idx.get(int(mid))
        if a is None:
            return []
        name = self.m.at[a, "name"]
        return self.rank(ctx, n, seeds={a: 1.0}, exclude=np.isin(self.ids, [mid]), w=dict(c=.65, s=.1, g=.05, q=.15, p=.05),
                         context=lambda i, s: f"{why_prefix} {name} (content similarity {self.sim[a, i]:.0%}).")

    def movie_night(self, ctx, company, mood_label, level, n=4, rng_seed=0):
        return self.mood_picks(ctx, NIGHT_MOOD[mood_label], n=n, mode=NIGHT_LEVEL[level],
                               companions=NIGHT_COMPANY[company], rng_seed=rng_seed)

    def double_feature(self, ctx, rng_seed=0):
        firsts = self.rank(ctx, 12, mode="explore", min_ratings=20, rng_seed=rng_seed)
        if not firsts:
            return None
        rng = np.random.default_rng(rng_seed)
        f = firsts[int(rng.integers(min(len(firsts), 8)))]
        fi = self.idx[f["movieId"]]
        gl = self.m.at[fi, "genre_list"]
        cands = self.rank(ctx, 20, seeds={fi: 1.0}, exclude=self.excluded(ctx) | np.isin(self.ids, [f["movieId"]]),
                          w=dict(c=.5, s=.1, g=0, q=.3, p=.1), min_ratings=15, cap_stem=1)
        cands = [c for c in cands if self.stems[self.idx[c["movieId"]]] != self.stems[fi]
                 and set(gl) & set(self.m.at[self.idx[c["movieId"]], "genre_list"])]
        if not cands:
            return None
        s = cands[0]; si = self.idx[s["movieId"]]
        shared = [g for g in gl if g in self.m.at[si, "genre_list"]]
        why = f"Both share {', '.join(shared[:3])} (content similarity {self.sim[fi, si]:.0%})."
        f["why"] = "Your opener: " + (self._explain(fi, self._signals(self.seeds_from(ctx), [])))
        s["why"] = why
        return {"first": f, "second": s}

    def bedtime(self, ctx, rng_seed=0):
        heavy = self.G[:, [self.gi[g] for g in ("Horror", "War", "Thriller") if g in self.gi]].sum(1) > 0
        gentle = np.where(heavy, 0.0, 1.0).astype(np.float32)
        recs = self.rank(ctx, 1, gate=~heavy, min_ratings=20, rng_seed=rng_seed, extra=gentle, extra_w=0.1,
                         badge="pick")
        if recs:
            recs[0]["why"] = "Picked as a gentler watch (skips Horror/War/Thriller). " + recs[0]["why"]
        return recs

    def todays_pick(self, ctx, day_key: str):
        sig_txt = f"{day_key}|{bool(ctx.get('history'))}"
        seed = int(sum(ord(c) * (k + 1) for k, c in enumerate(sig_txt)))  # deterministic (no hash())
        pool = self.rank(ctx, 15, min_ratings=30, badge="pick", rng_seed=seed)
        if not pool:
            return None
        return pool[seed % len(pool)]

    def missed(self, ctx, shown_ids, n=6):
        ex = self.excluded(ctx, extra_ids=shown_ids)
        return self.rank(ctx, n, mode="explore", exclude=ex, badge="explore", min_ratings=10, use=("history", "list"))

    def mix_it_up(self, ctx, rng_seed=0):
        out, taken = [], []
        for mode, badge in (("familiar", "similar"), ("explore", "explore"), ("wild", "wild")):
            ex = self.excluded(ctx, extra_ids=taken)
            r = self.rank(ctx, 1, mode=mode, exclude=ex, badge=badge, rng_seed=rng_seed + len(out), min_ratings=15)
            if r:
                out.append(r[0]); taken.append(r[0]["movieId"])
        return out

    def list_recs(self, ctx, n=8):
        lst = ctx.get("list", [])
        if not lst:
            return [], []
        seeds = self.seeds_from({"list": lst}, ("list",))
        seeds = {i: 1.0 for i in seeds}
        top = [self.genres[k] for k in np.argsort(-self._affinity(seeds, [])) [:3]]
        recs = self.rank(ctx, n, seeds=seeds, badge="list",
                         context=lambda i, s: "Fits the taste of your saved movies. " + self._explain(i, s))
        return recs, top

    def collaborative(self, ctx, n=12):
        seeds = self.seeds_from(ctx)
        ex = self.excluded(ctx)
        if seeds:
            idxs = np.fromiter(seeds.keys(), int)
            ws = np.array([seeds[i] for i in idxs], np.float32)
            v = (ws[:, None] * self.Qn[idxs]).sum(0); v /= max(np.linalg.norm(v), 1e-9)
            sc = (self.Qn @ v) * self.shrink
            ctxf = lambda i, s: "Collaborative filtering (SVD): sits close to your movies in the latent space of user ratings."
            wts = dict(c=0, s=1.0, g=0, q=0, p=0)
            return self.rank(ctx, n, w=wts, exclude=ex, badge="collab", context=ctxf, min_ratings=15)
        return self.rank(ctx, n, w=dict(q=1, p=0), exclude=ex, badge="collab", min_ratings=30,
                         context=lambda i, s: "Highest SVD-adjusted rating quality in the dataset (no history yet).")

    def user_demo(self, user_id, n=8):
        from .collaborative import predict_user_ratings
        p = predict_user_ratings(self.svd, user_id)
        if p is None:
            return []
        rated = set(self.svd.get("user_rated", {}).get(int(user_id), []))
        sc = np.where(np.isin(self.ids, list(rated)), -9, p + 0.0 * self.q)
        sc[self.n_rat < 15] = -9
        top = np.argsort(-sc)[:n]
        return [{"movieId": int(self.ids[i]), "badge": BADGES["collab"],
                 "why": f"SVD predicted rating for MovieLens user {user_id}: {p[i]:.2f}★."} for i in top]

    def multi_genre_row(self, ctx, genres, n=12):
        """Movies blending several of the user's dominant genres (>=2 of them when possible)."""
        cols = [self.gi[g] for g in genres if g in self.gi]
        if not cols:
            return []
        gate = self.G[:, cols].sum(1) >= min(2, len(cols))
        return self.rank(ctx, n, use=("history",), gate=gate, badge="similar",
                         context=lambda i, s: "Blends your top genres: "
                         + ", ".join(g for g in genres if g in self.m.at[i, "genre_list"]) + ".")

    def genre_top(self, genre, ctx, n=18, offset=0):
        gate = self.G[:, self.gi[genre]] > 0
        recs = self.rank(ctx, n + offset, use=("history",), gate=gate, w=dict(c=.2, s=0, g=.1, q=.45, p=.25),
                         exclude=np.zeros(self.n, bool), badge="similar", min_ratings=10, cap_stem=3,
                         context=lambda i, s: f"Top-rated {genre} ({self.m.at[i, 'avg_rating']:.1f}★, {self.n_rat[i]} ratings).")
        return recs[offset:offset + n]

    def search(self, query: str, n: int = 24) -> list[dict]:
        q = (query or "").strip().lower()
        if not q:
            return []
        names = self.m["name"].str.lower()
        words = [w for w in re.findall(r"[a-z0-9']+", q) if w]
        g_full = SEARCH_SYNONYMS.get(q)  # the whole query is a genre keyword ("funny", "animation")
        g = g_full or next((SEARCH_SYNONYMS[w] for w in words if w in SEARCH_SYNONYMS), None)
        score = np.zeros(self.n)
        tscore = np.where(names == q, 100, 0) + np.where(names.str.startswith(q), 80, 0)
        tscore = tscore + np.where(names.str.contains(r"\b" + re.escape(q), regex=True), 60, 0)
        tscore = tscore + np.where(names.str.contains(re.escape(q), regex=False), 40, 0)
        if len(words) > 1:
            tscore = tscore + np.where(np.all([names.str.contains(re.escape(w), regex=False) for w in words], axis=0), 30, 0)
        if g_full:  # genre keyword: genre matches lead, title hits only nudge
            tscore = tscore * 0.1
        score += tscore
        if g and g in self.gi:
            score += np.where(self.G[:, self.gi[g]] > 0, 60 if g_full else 20, 0)
        hit = score > 0
        score = score + 8 * self.q + 4 * self.pop
        score[~hit] = -1
        order = np.argsort(-score)[:n]
        out = []
        for i in order:
            if score[i] < 0:
                break
            in_genre = bool(g and g in self.gi and self.G[i, self.gi[g]] > 0)
            why = (f"{g} movie matching “{query}”." if in_genre and (g_full or score[i] < 30)
                   else f"Matches your search “{query}” in the title.")
            out.append({"movieId": int(self.ids[i]), "why": why, "badge": ""})
        return out
