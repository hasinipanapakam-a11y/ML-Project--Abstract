"""Taste analytics derived from the user's *actual* session actions. Nothing is invented."""
from __future__ import annotations

from collections import Counter

MOODS = {
    "chill": {"emoji": "😌", "label": "Chill & Relax", "title": "CHILL & RELAX",
              "genres": {"Comedy": 1, "Romance": .8, "Animation": .8, "Fantasy": .6, "Musical": .6, "Documentary": .5},
              "avoid": ["Horror", "Thriller", "War", "Crime"]},
    "laugh": {"emoji": "😂", "label": "Make Me Laugh", "title": "COMEDY",
              "genres": {"Comedy": 1, "Animation": .4, "Children": .3}, "avoid": ["Horror", "War"]},
    "emotional": {"emoji": "😭", "label": "Emotional", "title": "EMOTIONAL",
                  "genres": {"Drama": 1, "Romance": .7, "War": .6, "Musical": .4}, "avoid": ["Horror"]},
    "romantic": {"emoji": "❤️", "label": "Romantic", "title": "ROMANTIC",
                 "genres": {"Romance": 1, "Comedy": .4, "Drama": .4}, "avoid": ["Horror", "War"]},
    "edge": {"emoji": "😱", "label": "Keep Me On Edge", "title": "EDGE-OF-YOUR-SEAT",
             "genres": {"Thriller": 1, "Mystery": .8, "Crime": .7, "Horror": .4}, "avoid": ["Children", "Musical"]},
    "adrenaline": {"emoji": "🔥", "label": "Adrenaline", "title": "ADRENALINE",
                   "genres": {"Action": 1, "Adventure": .7, "Sci-Fi": .5, "Thriller": .4}, "avoid": ["Documentary", "Musical"]},
    "scary": {"emoji": "👻", "label": "Something Scary", "title": "SCARY",
              "genres": {"Horror": 1, "Thriller": .5, "Mystery": .4}, "avoid": ["Children", "Musical", "Romance"]},
    "think": {"emoji": "🧠", "label": "Make Me Think", "title": "MIND-BENDING",
              "genres": {"Mystery": 1, "Sci-Fi": .8, "Drama": .6, "Documentary": .7, "Crime": .4}, "avoid": ["Children"]},
    "feelgood": {"emoji": "🌟", "label": "Feel Good", "title": "FEEL-GOOD",
                 "genres": {"Comedy": 1, "Animation": .8, "Musical": .8, "Children": .6, "Adventure": .5, "Romance": .5},
                 "avoid": ["Horror", "War", "Crime", "Thriller"]},
    "different": {"emoji": "🎨", "label": "Something Different", "title": "OFF-THE-BEATEN-PATH",
                  "genres": {"Documentary": 1, "Film-Noir": 1, "Western": .8, "Musical": .6, "Fantasy": .4, "War": .4},
                  "avoid": [], "niche": True},
}

# Movie Night inputs ---------------------------------------------------------
NIGHT_COMPANY = {
    "solo": {"label": "👤 Just Me", "genres": {}, "avoid": []},
    "friends": {"label": "👫 Friends", "genres": {"Comedy": .6, "Action": .6, "Adventure": .4}, "avoid": ["Documentary"]},
    "date": {"label": "❤️ Date Night", "genres": {"Romance": .8, "Comedy": .5, "Drama": .3}, "avoid": ["Horror", "War"]},
    "family": {"label": "👨‍👩‍👧 Family", "genres": {"Animation": .9, "Children": .9, "Adventure": .6, "Comedy": .5, "Fantasy": .5},
               "avoid": ["Horror", "Crime", "War", "Thriller", "Film-Noir"]},
    "group": {"label": "🎉 Group", "genres": {"Comedy": .7, "Action": .6, "Horror": .3, "Adventure": .4}, "avoid": ["Documentary"]},
}
NIGHT_MOOD = {"Funny": "laugh", "Relaxing": "chill", "Exciting": "adrenaline",
              "Emotional": "emotional", "Romantic": "romantic", "Scary": "scary"}
NIGHT_LEVEL = {"🎯 Safe Pick": "familiar", "🌶️ Something Different": "explore", "🎲 Wild Card": "wild"}

BADGES = {"similar": "✨ Similar to You", "mood": "🎭 Mood Match", "trend": "🔥 Trending For You",
          "explore": "🌶️ Explore", "wild": "🎲 Wildcard", "gem": "🕵️ Hidden Gem",
          "collab": "🤖 Collaborative", "list": "❤️ From Your List", "pick": "🎯 Pick"}


def taste_stats(genre_lists: list[list[str]], ratings: list[float | None], years: list[float],
                global_counts: dict | None = None) -> dict:
    """Stats over the watch history. `genre_lists[i]` = genres of watched movie i.

    Ties are broken toward the genre that is *rarer in the dataset* (more distinctive),
    e.g. Animation beats Adventure when both appear in every watched movie.
    """
    gc = global_counts or {}
    n = len(genre_lists)
    counts: Counter = Counter(g for gl in genre_lists for g in set(gl))
    ordered = sorted(counts.items(), key=lambda x: (-x[1], gc.get(x[0], 0), x[0]))
    vals = [r for r in ratings if r is not None]
    return {
        "n": n, "counts": ordered, "n_genres": len(counts),
        "favorite": ordered[0][0] if ordered else None,
        "shares": {g: c / n for g, c in ordered} if n else {},
        "avg_community_rating": (sum(vals) / len(vals)) if vals else None,
        "pre1980_share": (sum(1 for y in years if y == y and y < 1980) / n) if n else 0.0,
    }


def profile_label(stats: dict) -> tuple[str, str]:
    """(label, explanation) derived from the genre distribution."""
    n = stats["n"]
    if n < 3:
        return "🎞️ Keep watching", "Keep watching to discover your movie profile."
    shares = stats["shares"]
    top, top_share = stats["favorite"], shares[stats["favorite"]]
    if stats["pre1980_share"] >= 0.5:
        return "🎬 Classic Explorer", f"{stats['pre1980_share']:.0%} of your watched movies were released before 1980."
    if top_share >= 0.5:
        word = {"Comedy": "Fan", "Drama": "Devotee", "Horror": "Fan", "Romance": "Fan"}.get(top, "Explorer")
        emoji = {"Animation": "🎭", "Comedy": "😂", "Action": "🔥", "Horror": "👻", "Romance": "❤️"}.get(top, "🎬")
        return f"{emoji} {top} {word}", f"{top} appears in {top_share:.0%} of the {n} movies in your watch history."
    if stats["n_genres"] >= 8 and top_share < 0.35:
        return "🌎 Genre Hopper", f"You've covered {stats['n_genres']} genres and no single genre dominates."
    return "🌈 Mixed Taste", f"Your top genre ({top}) covers {top_share:.0%} of your history, across {stats['n_genres']} genres."


def dominant_genres(stats: dict, k: int = 3, min_share: float = 0.3) -> list[str]:
    return [g for g, c in stats["counts"][:k] if stats["n"] and c / stats["n"] >= min_share]


def genre_section_title(stats: dict) -> tuple[str, str | None]:
    """('✨ BECAUSE YOU LIKE ANIMATION', genre) or ('🎬 MATCHING YOUR TASTE', None)."""
    if stats["n"] < 2:
        return "🎬 MATCHING YOUR TASTE", None
    top = stats["favorite"]
    if stats["shares"][top] >= 0.6:
        emoji = {"Animation": "✨", "Comedy": "😂"}.get(top, "🎯")
        return f"{emoji} BECAUSE YOU LIKE {top.upper()}", top
    return "🎬 MATCHING YOUR TASTE", None


def taste_evolution(history_chrono: list[list[str]]) -> dict | None:
    """Compare the earlier half to the recent half of history (oldest -> newest). Needs >= 6."""
    n = len(history_chrono)
    if n < 6:
        return None
    half = n // 2
    early, recent = history_chrono[:half], history_chrono[n - half:]

    def share(block):
        c = Counter(g for gl in block for g in set(gl))
        return {g: v / len(block) for g, v in c.items()}

    se, sr = share(early), share(recent)
    top = lambda s: [g for g, _ in sorted(s.items(), key=lambda x: -x[1])[:3]]
    delta = {g: sr.get(g, 0) - se.get(g, 0) for g in set(se) | set(sr)}
    up = [g for g, d in sorted(delta.items(), key=lambda x: -x[1]) if d >= 0.2][:2]
    down = [g for g, d in sorted(delta.items(), key=lambda x: x[1]) if d <= -0.2][:2]
    if up:
        msg = f"Your recent watch history contains more {' and '.join(up)} movies than your earlier history."
    elif down:
        msg = f"Your recent watch history contains fewer {' and '.join(down)} movies than your earlier history."
    else:
        msg = "Your recent and earlier watch history have a similar genre mix."
    return {"early": top(se), "recent": top(sr), "message": msg}


def milestones(watched_ever: int, genres_seen: int, moods_tried: int, saved_ever: int) -> list[dict]:
    defs = [("🍿", "First Movie", watched_ever >= 1), ("🎬", "5 Movies Watched", watched_ever >= 5),
            ("🎬", "10 Movies Watched", watched_ever >= 10), ("🌈", "5 Genres Explored", genres_seen >= 5),
            ("🎭", "5 Moods Tried", moods_tried >= 5), ("❤️", "5 Movies Saved", saved_ever >= 5)]
    return [{"icon": i, "name": n, "unlocked": u} for i, n, u in defs]
