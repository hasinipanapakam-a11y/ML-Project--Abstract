"""Data loading, cleaning and shared constants for CineMatch."""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

NO_GENRE = "(no genres listed)"
NON_GENRES = {NO_GENRE, "IMAX"}  # IMAX is a format, not a genre

GENRE_EMOJI = {
    "Animation": "🎨", "Comedy": "😂", "Action": "🔥", "Romance": "❤️",
    "Horror": "👻", "Drama": "🧠", "Sci-Fi": "🌌", "Thriller": "🕵️",
    "Adventure": "🗺️", "Children": "🧸", "Crime": "🔫", "Fantasy": "🧙",
    "Mystery": "🔍", "War": "🪖", "Musical": "🎵", "Documentary": "🎥",
    "Western": "🤠", "Film-Noir": "🎞️",
}


def genre_label(g: str) -> str:
    return f"{GENRE_EMOJI.get(g, '🎬')} {g}"


_YEAR = re.compile(r"\((\d{4})\)\s*$")
_ARTICLE = re.compile(r"^(.*), (The|A|An)$")


def display_title(raw: str) -> tuple[str, float]:
    """'Shining, The (Alt Title) (1980)' -> ('The Shining', 1980)."""
    t = raw.strip()
    m = _YEAR.search(t)
    year = float(m.group(1)) if m else np.nan
    if m:
        t = t[: m.start()].strip()
    # drop trailing alternative-title parenthetical, but never the whole title
    t2 = re.sub(r"\s*\([^()]*\)\s*$", "", t).strip()
    if t2:
        t = t2
    a = _ARTICLE.match(t)
    if a:
        t = f"{a.group(2)} {a.group(1)}"
    return t, year


def load_data(data_dir: str | Path = "data") -> dict:
    """Load + validate movies / ratings / links. Joins only on movieId."""
    d = Path(data_dir)
    report: dict = {}
    movies = pd.read_csv(d / "movies.csv")
    ratings = pd.read_csv(d / "ratings.csv")
    links = pd.read_csv(d / "links.csv")
    report["raw_rows"] = {"movies": len(movies), "ratings": len(ratings), "links": len(links)}

    # --- movies ---
    movies = movies.dropna(subset=["movieId", "title"]).copy()
    movies["movieId"] = movies["movieId"].astype(int)
    report["dup_movies"] = int(movies.duplicated("movieId").sum())
    movies = movies.drop_duplicates("movieId", keep="first")
    movies["genres"] = movies["genres"].fillna(NO_GENRE).astype(str)

    # --- links (fills tmdbId when the movies file lacks it) ---
    links = links.dropna(subset=["movieId"]).copy()
    links["movieId"] = links["movieId"].astype(int)
    links = links.drop_duplicates("movieId", keep="first")
    links = links.rename(columns={"tmdbId": "tmdbId_links"})[["movieId", "tmdbId_links"]]
    movies = movies.merge(links, on="movieId", how="left")
    if "tmdbId" in movies.columns:
        movies["tmdbId"] = movies["tmdbId"].combine_first(movies["tmdbId_links"])
    else:
        movies["tmdbId"] = movies["tmdbId_links"]
    movies = movies.drop(columns=["tmdbId_links"])
    report["missing_tmdb"] = int(movies["tmdbId"].isna().sum())

    # --- ratings ---
    ratings = ratings[["userId", "movieId", "rating"]].copy()
    ratings["rating"] = pd.to_numeric(ratings["rating"], errors="coerce")
    ratings = ratings.dropna()
    ratings[["userId", "movieId"]] = ratings[["userId", "movieId"]].astype(int)
    report["dup_ratings"] = int(ratings.duplicated(["userId", "movieId"]).sum())
    ratings = ratings.drop_duplicates(["userId", "movieId"], keep="last")
    ratings["rating"] = ratings["rating"].clip(0.5, 5.0)
    orphan = ~ratings["movieId"].isin(movies["movieId"])
    report["orphan_ratings"] = int(orphan.sum())
    ratings = ratings[~orphan]

    # --- derived movie fields ---
    parsed = movies["title"].map(display_title)
    movies["name"] = parsed.map(lambda x: x[0])
    movies["year"] = parsed.map(lambda x: x[1])
    movies["genre_list"] = movies["genres"].map(
        lambda s: [g for g in s.split("|") if g and g not in NON_GENRES]
    )

    stats = ratings.groupby("movieId")["rating"].agg(n_ratings="size", avg_rating="mean")
    movies = movies.merge(stats, on="movieId", how="left")
    movies["n_ratings"] = movies["n_ratings"].fillna(0).astype(int)
    gmean = float(ratings["rating"].mean())
    m = 15.0  # prior strength: shrinks small-sample averages toward the global mean
    v = movies["n_ratings"].astype(float)
    r = movies["avg_rating"].fillna(gmean)
    movies["bayes"] = (v / (v + m)) * r + (m / (v + m)) * gmean
    movies = movies.sort_values("movieId").reset_index(drop=True)

    all_genres = sorted({g for gl in movies["genre_list"] for g in gl})
    n_users = int(ratings["userId"].nunique())
    report.update(
        n_movies=len(movies), n_ratings=len(ratings), n_users=n_users,
        n_genres=len(all_genres), genres=all_genres, global_mean=gmean,
        sparsity=1 - len(ratings) / (len(movies) * n_users),
        year_min=int(movies["year"].min()), year_max=int(movies["year"].max()),
    )
    return {"movies": movies, "ratings": ratings, "report": report}
