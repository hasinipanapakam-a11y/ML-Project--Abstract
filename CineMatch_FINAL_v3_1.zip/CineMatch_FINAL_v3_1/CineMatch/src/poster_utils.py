"""TMDB artwork + metadata with validation, caching, graceful failure and generated fallbacks."""
from __future__ import annotations

import hashlib
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from html import escape
from urllib.parse import quote

import requests
import streamlit as st

API = "https://api.themoviedb.org/3"
# Official alias of the same API: some ISPs/firewalls block api.themoviedb.org but allow api.tmdb.org.
# Override/prepend your own proxy with the TMDB_API_BASE environment variable.
BASES = [b for b in (os.environ.get("TMDB_API_BASE"), API, "https://api.tmdb.org/3") if b]
_good_base: str | None = None
IMG = "https://image.tmdb.org/t/p"
_fails = 0
_down_until = 0.0  # circuit breaker: after a network failure skip TMDB briefly instead of timing out per card
_lock = threading.Lock()


class TMDBError(Exception):
    """Transient failure (network/5xx/429). Raised so st.cache_data does NOT cache it."""


last_error: str | None = None  # shown in the app so a bad key / no internet is visible instead of silent


def get_api_key(override: str | None = None) -> str | None:
    """Key priority: key typed into the app (this session only) > env var > Streamlit secrets."""
    key = (override or "").strip() or os.environ.get("TMDB_API_KEY")
    if not key:
        try:
            key = st.secrets["TMDB_API_KEY"]
        except Exception:  # no secrets file / key missing
            key = None
    key = (key or "").strip()
    return key or None


def _request(path: str, params: dict, headers: dict, timeout: float):
    """GET against the first reachable API host (remembers the one that worked)."""
    global _good_base
    bases = ([_good_base] if _good_base else []) + [b for b in BASES if b != _good_base]
    err: Exception | None = None
    for base in bases:
        try:
            r = requests.get(f"{base}{path}", params=params, headers=headers, timeout=timeout)
            _good_base = base
            return r
        except requests.RequestException as e:
            err = e
    raise err  # type: ignore[misc]


def _auth(key: str) -> tuple[dict, dict]:
    """v3 API key -> ?api_key=...  ;  v4 'Read Access Token' (starts with eyJ) -> Bearer header."""
    return ({}, {"Authorization": f"Bearer {key}"}) if key.startswith("eyJ") else ({"api_key": key}, {})


def test_connection(key: str) -> tuple[bool, str]:
    """Live check used by the in-app 'Test connection' button."""
    global last_error
    try:
        prm, hdr = _auth(key)
        r = _request("/movie/862", prm, hdr, 8)
    except requests.RequestException as e:
        last_error = (f"Cannot reach TMDB ({type(e).__name__}) on api.themoviedb.org or api.tmdb.org. Your ISP/firewall may block TMDB: "
                      "try a mobile hotspot or VPN, or set your DNS to 1.1.1.1 / 8.8.8.8.")
        return False, last_error
    if r.status_code in (401, 403):
        last_error = "TMDB rejected this key. Use the v3 “API Key” (32 characters) from themoviedb.org → Settings → API."
        return False, last_error
    if r.status_code != 200:
        return False, f"TMDB answered with status {r.status_code}."
    global _down_until, _fails
    with _lock:
        _down_until, _fails = 0.0, 0
    last_error = None
    return True, f"Connected ✓ — TMDB returned “{r.json().get('title', 'Toy Story')}”. Posters will load now."


def _get(path: str, params: dict, key: str):
    global _down_until, _fails, last_error
    if time.time() < _down_until:
        raise TMDBError("TMDB temporarily skipped")
    try:
        prm, hdr = _auth(key)
        for attempt in (0, 1):  # one polite retry on timeouts / rate limits / 5xx
            r = _request(path, {**params, **prm}, hdr, 6)
            if attempt == 0 and (r.status_code == 429 or r.status_code >= 500):
                time.sleep(min(float((getattr(r, "headers", {}) or {}).get("Retry-After", 1)), 2.0))
                continue
            break
    except requests.RequestException as e:
        last_error = f"Cannot reach TMDB ({type(e).__name__}). Your ISP/firewall may block it — try a hotspot/VPN or DNS 1.1.1.1."
        with _lock:
            _fails += 1
            if _fails >= 3:  # three consecutive network failures -> pause TMDB briefly
                _down_until = time.time() + 45
                _fails = 0
        raise TMDBError(str(e)) from e
    with _lock:
        _fails = 0
    if r.status_code == 404:
        return None
    if r.status_code in (401, 403):
        last_error = "TMDB rejected the API key (use the v3 “API Key”)."
        with _lock:
            _down_until = time.time() + 600  # bad key: stop hammering
        raise TMDBError("TMDB rejected the API key")
    if r.status_code == 429 or r.status_code >= 500:
        raise TMDBError(f"TMDB {r.status_code}")
    r.raise_for_status()
    return r.json()


def _ratio(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower().strip(), b.lower().strip()).ratio()


def _year(release_date: str | None) -> int | None:
    try:
        return int((release_date or "")[:4])
    except ValueError:
        return None


def _year_ok(rd, year, tol=1) -> bool:
    y = _year(rd)
    return year is None or y is None or abs(y - year) <= tol


def _title_ok(res: dict, title: str, thr: float) -> bool:
    return max(_ratio(res.get("title") or "", title), _ratio(res.get("original_title") or "", title)) >= thr


SAFE_US = {"G", "PG", "PG-13", "TV-Y", "TV-Y7", "TV-G", "TV-PG", "TV-14"}   # strict whitelist
SAFE_IN = {"U", "UA"}
SAFE_GB = {"U", "PG", "12", "12A"}
BLOCK_US = {"NC-17", "X"}          # US adult-only ratings
BLOCK_IN = {"A"}                   # India "Adult" certificate
FALLBACK_ONLY = ("en", None)


def _certs(d: dict) -> dict:
    out = {}
    for c in (d.get("release_dates") or {}).get("results", []):
        for r in c.get("release_dates", []):
            if r.get("certification"):
                out.setdefault(c.get("iso_3166_1"), r["certification"].strip())
                break
    return out


def _normalise(d: dict, source: str) -> dict:
    certs = _certs(d)
    posters = [p for p in (d.get("images") or {}).get("posters", []) if p.get("file_path")]
    posters.sort(key=lambda p: (p.get("iso_639_1") not in FALLBACK_ONLY, -(p.get("vote_average") or 0), -(p.get("vote_count") or 0)))
    adult_cert = certs.get("US") in BLOCK_US or certs.get("IN") in BLOCK_IN
    return {
        "tmdb_id": d.get("id"), "title": d.get("title"), "overview": d.get("overview") or "",
        "tagline": d.get("tagline") or "", "poster_path": d.get("poster_path"),
        "alt_posters": [p["file_path"] for p in posters[:3]],
        "backdrop_path": d.get("backdrop_path"), "runtime": d.get("runtime"),
        "language": d.get("original_language"), "release_date": d.get("release_date"),
        "countries": [c.get("iso_3166_1") for c in d.get("production_countries", []) if c.get("iso_3166_1")],
        "vote_average": d.get("vote_average"), "vote_count": d.get("vote_count"), "source": source,
        "adult": bool(d.get("adult")) or adult_cert, "certs": certs,
    }


_DETAIL = {"language": "en-US", "append_to_response": "images,release_dates", "include_image_language": "en,null"}


@st.cache_data(ttl=7 * 24 * 3600, show_spinner=False, max_entries=5000)
def fetch_tmdb(tmdb_id: int | None, title: str, year: int | None, api_key: str) -> dict:
    """Artwork priority: 1) MovieLens tmdbId, 2) validated by title/year, 3) validated title search.

    Returns {} when nothing trustworthy was found (cached); raises TMDBError on transient failures (not cached).
    """
    if tmdb_id:
        d = _get(f"/movie/{int(tmdb_id)}", _DETAIL, api_key)
        # the MovieLens id is authoritative: only reject when BOTH year and title clearly disagree
        if d and (_year_ok(d.get("release_date"), year, 2) or _title_ok(d, title, 0.5)):
            return _normalise(d, "tmdbId")
    # fallback: title search, never trust results[0] blindly
    for params in ({"query": title, "year": year} if year else None, {"query": title}):
        if params is None:
            continue
        res = _get("/search/movie", {**params, "language": "en-US", "include_adult": "false"}, api_key)
        for cand in (res or {}).get("results", [])[:10]:
            if _title_ok(cand, title, 0.8) and _year_ok(cand.get("release_date"), year, 1):
                d = _get(f"/movie/{cand['id']}", _DETAIL, api_key)
                return _normalise(d or cand, "search")
    return {}


def safe_fetch(tmdb_id, title, year, api_key) -> dict:
    if not api_key:
        return {}
    try:
        return fetch_tmdb(None if tmdb_id is None else int(tmdb_id), title, year, api_key) or {}
    except Exception:
        return {}


def prefetch(items: list[tuple], api_key: str | None, workers: int = 8) -> None:
    """Warm the cache for [(tmdb_id, title, year), ...] in parallel."""
    if not api_key or not items or time.time() < _down_until:
        return
    ctx = None
    try:
        from streamlit.runtime.scriptrunner import add_script_run_ctx, get_script_run_ctx
        ctx = get_script_run_ctx()
    except Exception:
        add_script_run_ctx = None

    def init():
        if ctx is not None and add_script_run_ctx:
            try:
                add_script_run_ctx(threading.current_thread(), ctx)
            except Exception:
                pass

    with ThreadPoolExecutor(max_workers=workers, initializer=init) as ex:
        list(ex.map(lambda it: safe_fetch(it[0], it[1], it[2], api_key), items))


# ------------------------------------------------------------------ fallback art
_GENRE_HUE = {"Animation": 200, "Comedy": 38, "Action": 8, "Romance": 330, "Horror": 280, "Drama": 225,
              "Sci-Fi": 185, "Thriller": 255, "Adventure": 150, "Children": 170, "Crime": 350, "Fantasy": 265,
              "Mystery": 245, "War": 20, "Musical": 310, "Documentary": 120, "Western": 28, "Film-Noir": 215}
_GENRE_ICON = {"Animation": "🎨", "Comedy": "😂", "Action": "🔥", "Romance": "❤️", "Horror": "👻", "Drama": "🎭",
               "Sci-Fi": "🌌", "Thriller": "🕵️", "Adventure": "🗺️", "Children": "🧸", "Crime": "🔎",
               "Fantasy": "🧙", "Mystery": "🔍", "War": "🪖", "Musical": "🎵", "Documentary": "🎥",
               "Western": "🤠", "Film-Noir": "🎞️"}


def _wrap(text: str, width: int, max_lines: int) -> list[str]:
    lines, cur = [], ""
    for w in text.split():
        if len(cur) + len(w) + (1 if cur else 0) <= width:
            cur = f"{cur} {w}".strip()
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1][: max(0, width - 1)] + "…"
    return lines or [text[:width]]


@st.cache_data(show_spinner=False, max_entries=6000)
def fallback_art(title: str, year: int | None, genres: tuple, wide: bool = False) -> str:
    """Polished generated artwork (SVG data-URI) from title / genre / year. Never blank."""
    h0 = int(hashlib.md5(title.encode()).hexdigest()[:6], 16)
    g0 = genres[0] if genres else ""
    hue = (_GENRE_HUE.get(g0, h0 % 360) + (h0 % 24) - 12) % 360
    hue2 = (hue + 48) % 360
    W, H = (1280, 540) if wide else (300, 450)
    icon = _GENRE_ICON.get(g0, "🎬")
    fs = 54 if wide else 30
    width = 26 if wide else 12
    lines = _wrap(title, width, 3)
    x = 90 if wide else W / 2
    anchor = "start" if wide else "middle"
    y0 = (H / 2 - 20) if wide else (H * 0.50 - (len(lines) - 1) * fs * 0.6)
    tspans = "".join(f'<tspan x="{x}" dy="{0 if k == 0 else fs * 1.2}">{escape(l)}</tspan>' for k, l in enumerate(lines))
    perf = "" if wide else "".join(
        f'<rect x="8" y="{20 + k * 36}" width="10" height="16" rx="3" fill="#fff" opacity=".10"/>'
        f'<rect x="{W - 18}" y="{20 + k * 36}" width="10" height="16" rx="3" fill="#fff" opacity=".10"/>'
        for k in range(12))
    sub = " · ".join(genres[:3]) if genres else ""
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" preserveAspectRatio="xMidYMid slice">'
        f'<defs><linearGradient id="a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl({hue},55%,24%)"/>'
        f'<stop offset="1" stop-color="hsl({hue2},60%,9%)"/></linearGradient>'
        f'<radialGradient id="b" cx=".78" cy=".18" r=".7"><stop offset="0" stop-color="hsl({hue2},85%,60%)" stop-opacity=".45"/>'
        f'<stop offset="1" stop-color="hsl({hue2},85%,60%)" stop-opacity="0"/></radialGradient>'
        f'<linearGradient id="c" x1="0" y1="0" x2="0" y2="1"><stop offset=".45" stop-color="#000" stop-opacity="0"/>'
        f'<stop offset="1" stop-color="#05060f" stop-opacity=".75"/></linearGradient></defs>'
        f'<rect width="{W}" height="{H}" fill="url(#a)"/><rect width="{W}" height="{H}" fill="url(#b)"/>'
        f'<text x="{W * (0.86 if wide else 0.5)}" y="{H * (0.36 if wide else 0.24)}" font-size="{150 if wide else 84}" '
        f'text-anchor="middle" opacity=".18">{icon}</text>{perf}<rect width="{W}" height="{H}" fill="url(#c)"/>'
        f'<text x="{x}" y="{y0}" font-family="Georgia,\'Times New Roman\',serif" font-weight="700" font-size="{fs}" '
        f'fill="#f4f1ff" text-anchor="{anchor}">{tspans}</text>'
        f'<text x="{x}" y="{H - (62 if wide else 52)}" font-family="Helvetica,Arial,sans-serif" font-size="{22 if wide else 13}" '
        f'letter-spacing="3" fill="#cfc9ff" opacity=".85" text-anchor="{anchor}">{escape(sub.upper())}</text>'
        f'<text x="{x}" y="{H - (30 if wide else 30)}" font-family="Helvetica,Arial,sans-serif" font-size="{22 if wide else 14}" '
        f'letter-spacing="4" fill="#fff" opacity=".6" text-anchor="{anchor}">{year or ""}</text></svg>'
    )
    return "data:image/svg+xml;utf8," + quote(svg, safe="/:=,;-.()")


def art_allowed(meta: dict, level: str) -> bool:
    """Whether TMDB images may be shown for this movie.

    strict   : only when TMDB confirms a family-friendly age rating (G/PG/PG-13 or equivalent). Unknown -> hidden.
    standard : hide adult-flagged and R / NC-17 / X (US) or A (India) titles.
    off      : show everything.
    """
    if level == "off":
        return True
    certs = meta.get("certs") or {}
    us = certs.get("US")
    if level == "standard":
        return not (meta.get("adult") or us in {"R", "NC-17", "X"} or certs.get("IN") in BLOCK_IN)
    if meta.get("adult"):
        return False
    if us:
        return us in SAFE_US
    return certs.get("IN") in SAFE_IN or certs.get("GB") in SAFE_GB


ART_STATS: dict = {"poster": [], "alt_poster": [], "scene": [], "generated": [], "hidden_18": []}


def reset_art_stats() -> None:
    for v in ART_STATS.values():
        v.clear()


def get_art(info: dict, api_key: str | None, family: str | bool = "strict") -> dict:
    """Resolve artwork for one movie.

    Order: official poster -> alternate TMDB poster -> scene (backdrop) -> generated cinematic card.
    With a family level (strict/standard), movies that fail the age-rating check never use TMDB images (generated card instead).
    """
    meta = safe_fetch(info.get("tmdbId"), info["name"], info.get("year"), api_key) if api_key else {}
    genres = tuple(info.get("genres", []))
    fb = fallback_art(info["name"], info.get("year"), genres)
    fbw = fallback_art(info["name"], info.get("year"), genres, True)
    level = {True: "strict", False: "off"}.get(family, family)
    blocked = bool(meta) and not art_allowed(meta, level)
    if blocked:
        ART_STATS["hidden_18"].append(info["name"])
        return {"poster": None, "backdrop": None, "card": None, "meta": {**meta, "overview": meta.get("overview", "")},
                "fallback": fb, "fallback_wide": fbw, "blocked": True, "source": "hidden"}
    poster_path, source = meta.get("poster_path"), "poster"
    if not poster_path and meta.get("alt_posters"):
        poster_path, source = meta["alt_posters"][0], "alt_poster"
    poster = f"{IMG}/w500{poster_path}" if poster_path else None
    backdrop = f"{IMG}/w1280{meta['backdrop_path']}" if meta.get("backdrop_path") else None
    card = poster or (f"{IMG}/w780{meta['backdrop_path']}" if meta.get("backdrop_path") else None)  # scene beats blank
    if not poster and card:
        source = "scene"
    if not card:
        source = "generated"
    ART_STATS[source].append(info["name"])
    return {"poster": poster, "backdrop": backdrop, "card": card, "meta": meta, "fallback": fb,
            "fallback_wide": fbw, "blocked": False, "source": source}
