"""Streamlit-free tests for the data pipeline and recommendation logic.  Run:  python -m pytest tests -q
(or simply: python tests/test_engine.py)"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.collaborative import build_svd_model, get_svd_recommendations  # noqa: E402
from src.content_based import build_content_model, get_content_recommendations  # noqa: E402
from src.personalization import MOODS, profile_label, taste_evolution, taste_stats  # noqa: E402
from src.compare import (build_rating_index, compare_lists, content_recs_for_movie, content_recs_for_user,  # noqa: E402
                         cf_recs_for_movie, cf_recs_for_user, co_rating_stats, evaluate_offline)
from src.recommender import Engine  # noqa: E402
from src.utils import load_data  # noqa: E402

D = load_data(Path(__file__).resolve().parents[1] / "data")
M, R = D["movies"], D["ratings"]
CM = build_content_model(M)
SV = build_svd_model(R, M["movieId"].to_numpy())
E = Engine(M, CM, SV)
ID = {n: int(M[M.name == n].movieId.iloc[0]) for n in ["Toy Story", "Shrek", "Finding Nemo", "The Incredibles"]}
EMPTY = dict(history=[], list=[], faceoff=[], onboarding=[])
HIST = dict(history=[ID["The Incredibles"], ID["Finding Nemo"], ID["Shrek"], ID["Toy Story"]], list=[], faceoff=[], onboarding=[])


def ids(recs):
    return [r["movieId"] for r in recs]


def test_data_joins_and_cleaning():
    assert D["report"]["orphan_ratings"] == 0 and M.movieId.is_unique
    assert R.rating.between(0.5, 5).all() and not R.duplicated(["userId", "movieId"]).any()
    assert {"tmdbId", "name", "year", "genre_list", "bayes"} <= set(M.columns)


def test_content_based():
    r = get_content_recommendations(CM, M, "Toy Story (1995)", 10)
    assert len(r) == 10 and "Toy Story" not in set(r.name) and r.movieId.is_unique
    assert len(get_content_recommendations(CM, M, "no such movie zzz")) == 0


def test_svd():
    assert 0.5 < SV["rmse"] < 1.3 and SV["backend"] in ("surprise-svd", "numpy-svd")
    assert len(get_svd_recommendations(SV, M, seed_movie_ids=[1], n=5, exclude_ids=[1])) == 5


def test_because_you_watched_and_multi_history():
    r = ids(E.because_you_watched(HIST, ID["Toy Story"], 6))
    assert ID["Toy Story"] not in r and len(r) == len(set(r)) > 0
    m = ids(E.made_for_history(HIST, 12))
    assert not set(m) & set(HIST["history"]) and len(m) == len(set(m))


def test_discovery_modes_differ_and_exclude_watched():
    out = {mode: ids(E.made_for_history(HIST, 8, mode, 3)) for mode in ("familiar", "explore", "wild")}
    assert all(not set(v) & set(HIST["history"]) for v in out.values())
    assert out["familiar"] != out["wild"]


def test_mood_respects_genres():
    r = E.mood_picks(EMPTY, "scary", 10)
    assert r and all("Horror" in E.info_by_id(x["movieId"])["genres"] or "Thriller" in E.info_by_id(x["movieId"])["genres"]
                     or "Mystery" in E.info_by_id(x["movieId"])["genres"] for x in r)
    for k in MOODS:
        assert E.mood_picks(HIST, k, 6)


def test_quality_beats_tiny_samples():
    top = E.popular(EMPTY, 10)
    assert all(E.info_by_id(r["movieId"])["n"] >= 8 for r in top)
    small_5star = M[(M.n_ratings <= 3) & (M.avg_rating == 5.0)]
    assert len(small_5star) == 0 or not set(small_5star.movieId) & set(ids(top))


def test_hidden_gems_are_not_mainstream_or_obscure():
    for r in E.hidden_gems(HIST, 12):
        i = E.info_by_id(r["movieId"])
        assert 10 <= i["n"] <= E.p75


def test_surprise_never_repeats_and_skips_watched():
    seen = []
    for k in range(15):
        rec = E.surprise(HIST, seen, 100 + k)
        assert rec["movieId"] not in seen and rec["movieId"] not in HIST["history"]
        seen.append(rec["movieId"])


def test_todays_pick_is_deterministic():
    assert E.todays_pick(HIST, "2026-10-03") == E.todays_pick(HIST, "2026-10-03")


def test_other_features():
    assert len(E.movie_night(HIST, "family", "Funny", "🎯 Safe Pick", 4)) >= 3
    df = E.double_feature(HIST, 1)
    assert df and df["first"]["movieId"] != df["second"]["movieId"]
    assert len(E.bedtime(HIST)) == 1
    assert len(E.mix_it_up(HIST, 1)) == 3
    recs, top = E.list_recs(dict(history=[], list=[ID["Shrek"]], faceoff=[], onboarding=[]), 6)
    assert recs and ID["Shrek"] not in ids(recs)
    assert ID["Toy Story"] in ids(E.search("toy", 5)) and E.search("zzzqq") == []


def test_personalization_labels():
    s = taste_stats([["Animation", "Comedy"]] * 4, [3.5] * 4, [1995.0] * 4, {"Animation": 1, "Comedy": 2})
    assert s["favorite"] == "Animation" and "Animation" in profile_label(s)[0]
    assert profile_label(taste_stats([["Drama"]], [3.0], [2000.0]))[0].startswith("🎞️")
    assert taste_evolution([["Drama"]] * 3) is None


IDX = build_rating_index(R)


def test_auth_roundtrip(tmp_path=None):
    import importlib, os, tempfile
    os.environ["CINEMATCH_DB"] = tempfile.mktemp(suffix=".db")
    import src.auth as auth
    importlib.reload(auth)
    assert not auth.create_user("x", "secret1")[0] and not auth.create_user("good_name", "123")[0]
    assert auth.create_user("good_name", "secret1", "secret1")[0] and not auth.create_user("GOOD_NAME", "secret1")[0]
    assert auth.verify_user("good_name", "secret1")[0] and not auth.verify_user("good_name", "nope")[0]
    auth.save_state("good_name", {"watch_history": [1, 2], "watchlist": [3]})
    assert auth.load_state("good_name") == {"watch_history": [1, 2], "watchlist": [3]}


def test_two_separate_pipelines_and_comparison():
    cb, cf = content_recs_for_movie(CM, M, 1, 10), cf_recs_for_movie(SV, M, 1, 10)
    assert len(cb) == len(cf) == 10 and 1 not in [r["movieId"] for r in cb + cf]
    assert [r["movieId"] for r in cb] != [r["movieId"] for r in cf]            # genuinely different algorithms
    assert all(r["score"] <= cb[0]["score"] + 1e-9 for r in cb)                 # ranked by similarity
    c = compare_lists(cb, cf, M, {"Animation"})
    assert set(c["both"]) == {r["movieId"] for r in cb} & {r["movieId"] for r in cf}
    assert 0 <= c["jaccard"] <= 1 and len(c["table"]) == len(c["both"]) + len(c["only_cb"]) + len(c["only_cf"])


def test_user_mode_and_evidence():
    u = next(u for u, (m, r) in IDX["by_user"].items() if len(m) >= 20)
    um, ur = IDX["by_user"][u]
    cb, seeds = content_recs_for_user(CM, M, SV["id_index"], um, ur, 8)
    cf = cf_recs_for_user(SV, M, u, um, 8)
    assert len(cb) == len(cf) == 8 and not {r["movieId"] for r in cb + cf} & set(um.tolist())
    assert all(0.5 <= r["pred"] <= 5 for r in cf)
    s = co_rating_stats(IDX, 1, 2)
    assert s["liked_both"] <= s["n_both"]


def test_offline_evaluation_is_leak_free_and_sane():
    ev = evaluate_offline(E, R, SV, max_users=800)
    r = ev["ratings"]
    assert 0.7 < r["svd_rmse"] < 1.2 and 0.7 < r["content_rmse"] < 1.2
    assert r["item_mean_rmse"] >= min(r["svd_rmse"], r["content_rmse"]) - 0.05
    for k in ("content", "collab_pred", "collab_latent", "popular"):
        assert 0 <= ev["topk"][k]["hit_rate"] <= 1 and 0 <= ev["topk"][k]["mean_pct_rank"] <= 1
    assert ev["topk"]["popular"]["coverage"] < ev["topk"]["content"]["coverage"]


if __name__ == "__main__":
    fns = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for f in fns:
        f(); print("PASS", f.__name__)
    print(f"{len(fns)} tests passed")
